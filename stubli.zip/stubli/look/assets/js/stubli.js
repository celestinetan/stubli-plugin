/* Stubli theme: reading mode, carousel, content notes, click-to-play video,
 * and the "from your own Stubli" address form. No dependencies. */
( function () {
	'use strict';
	var T = window.stubliText || {};
	var root = document.documentElement;
	var store = {
		get: function ( k ) { try { return localStorage.getItem( k ); } catch ( e ) { return null; } },
		set: function ( k, v ) { try { localStorage.setItem( k, v ); } catch ( e ) {} }
	};

	/* Coming back with the browser's Back button, Safari can show the page as it
	   was before. When you're signed in, reload it so changes from the app show. */
	window.addEventListener( 'pageshow', function ( e ) { if ( e.persisted && document.body && document.body.classList.contains( 'logged-in' ) ) { location.reload(); } } );

	/* Collection tabs (0.2.121, Celestine 10 Nov): at most five, with labels of up to five characters, in one plain
	   row; on phones Journal, Guest book and Favourites sit in a row of their own above them (CSS only). The stacked
	   (0.2.118–0.2.119) and overlapping (0.2.120) layouts are gone. */

	/* Reading mode: Light ↔ Paper. No dark mode since 0.2.117 (Celestine 8 Nov); a saved Auto or Dark reads as Light. */
	var order = [ 'light', 'paper' ];
	function apply( pref ) {
		root.setAttribute( 'data-mode', pref );
		root.setAttribute( 'data-mode-pref', pref );
		document.querySelectorAll( '[data-st-mode]' ).forEach( function ( b ) {
			var label = ( T.modes && T.modes[ pref ] ) || pref;
			b.querySelector( '.st-mode-label' ).textContent = label;
			b.setAttribute( 'aria-label', ( T.readingMode || 'Reading mode' ) + ': ' + label );
		} );
	}
	// The owner's default (set in the head) applies until a visitor picks their own.
	var pref = store.get( 'stubli-mode' ) || root.getAttribute( 'data-mode-pref' ) || 'light';
	if ( order.indexOf( pref ) < 0 ) { pref = 'light'; }
	apply( pref );
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-st-mode]' );
		if ( ! b ) { return; }
		pref = order[ ( order.indexOf( pref ) + 1 ) % order.length ];
		store.set( 'stubli-mode', pref );
		apply( pref );
	} );

	/* Videos: tap to play, with sound. Nothing downloads before the tap. */
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-st-video]' );
		if ( ! b ) { return; }
		var v = document.createElement( 'video' ), img = b.querySelector( 'img' );
		v.controls = true; v.playsInline = true; v.setAttribute( 'playsinline', '' ); v.preload = 'auto';
		if ( img ) { v.poster = img.currentSrc || img.src; if ( img.naturalWidth ) { v.style.aspectRatio = img.naturalWidth + ' / ' + img.naturalHeight; } }
		if ( b.getAttribute( 'data-label' ) ) { v.setAttribute( 'aria-label', b.getAttribute( 'data-label' ) ); }
		var src = document.createElement( 'source' ); src.src = b.getAttribute( 'data-st-video' ); src.type = b.getAttribute( 'data-type' ) || 'video/mp4';
		v.appendChild( src ); v.className = 'st-video-file';
		b.parentNode.replaceChild( v, b );
		v.focus();
		var p = v.play(); if ( p && p.catch ) { p.catch( function () {} ); }
	} );

	/* Get started guide: one step at a time; the address keeps the step, so Back works. */
	var gs = document.querySelector( '[data-st-gs]' );
	if ( gs ) {
		var steps = gs.querySelectorAll( '[data-gs-step]' ), prog = gs.querySelector( '[data-gs-progress]' );
		var names = { 1: T.gs1 || 'Get a WordPress site', 2: T.gs2 || 'Add the Stubli plugin', 3: T.gs3 || 'Answer five quick questions', 4: T.gs4 || 'Invite your people' };
		gs.classList.add( 'is-live' );
		// Remembered on this device only: the step you reached, and a friend's invite.
		var mem = { get: function ( k ) { try { return localStorage.getItem( k ); } catch ( e ) { return null; } }, set: function ( k, v ) { try { localStorage.setItem( k, v ); } catch ( e ) {} } };
		var invite = null;
		try { invite = JSON.parse( mem.get( 'stubli-gs-invite' ) || 'null' ); } catch ( e ) { invite = null; }
		if ( invite && ( ! invite.url || Date.now() - ( invite.at || 0 ) > 30 * 864e5 ) ) { invite = null; }
		var keepInvite = function ( url, from ) {
			url = String( url || '' ).trim();
			if ( ! /^https?:\/\//i.test( url ) ) { url = 'https://' + url; }
			var u; try { u = new URL( url ); } catch ( e ) { return false; }
			if ( u.hostname.indexOf( '.' ) < 1 || ! u.searchParams.get( 't' ) ) { return false; }
			invite = { url: u.href, from: String( from || '' ).slice( 0, 60 ) || u.hostname, at: Date.now() };
			mem.set( 'stubli-gs-invite', JSON.stringify( invite ) );
			return true;
		};
		// Arriving from a friend's invite page: keep the invite, and start at the first question.
		try {
			var qs = new URLSearchParams( location.search );
			if ( qs.get( 'invite' ) && keepInvite( qs.get( 'invite' ), qs.get( 'from' ) ) ) { history.replaceState( null, '', location.pathname + '#gs-start' ); }
		} catch ( e ) {}
		var paintInvite = function () {
			var box = gs.querySelector( '[data-gs-invited]' ), h = gs.querySelector( '[data-gs-invited-h]' ), pick = gs.querySelector( '[data-gs-invite-pick]' );
			if ( ! box ) { return; }
			box.hidden = ! invite;
			if ( invite ) {
				h.textContent = ( T.invitedBy || '%s invited you' ).replace( '%s', invite.from );
				if ( pick ) { pick.hidden = true; }
			}
		};
		var where = { start: 1, host: 1, check: 1, noplugins: 1, install: 2, setup: 3, invite: 4 };
		var firstOf = { 1: 'start', 2: 'install', 3: 'setup', 4: 'invite' };
		var show = function ( focus ) {
			var id = ( location.hash || '' ).replace( '#gs-', '' ), cur = gs.querySelector( '[data-gs-step="' + id + '"]' ) || gs.querySelector( '[data-gs-step="start"]' );
			steps.forEach( function ( s ) { s.hidden = s !== cur; } );
			if ( focus ) { cur.classList.remove( 'is-in' ); void cur.offsetWidth; cur.classList.add( 'is-in' ); }
			var n = +cur.getAttribute( 'data-gs-n' );
			var sid = cur.getAttribute( 'data-gs-step' );
			gs.setAttribute( 'data-at', sid ); document.documentElement.setAttribute( 'data-gs-at', sid );
			if ( where[ sid ] ) { mem.set( 'stubli-gs-step', sid ); }
			paintInvite();
			var ibox = gs.querySelector( '[data-gs-invited]' );
			if ( ibox && 'start' !== sid ) { ibox.hidden = true; }
			if ( ! n ) {
				prog.hidden = true;
				if ( focus ) { var h0 = cur.querySelector( 'h2' ); h0.setAttribute( 'tabindex', '-1' ); h0.focus(); }
				return;
			}
			// A wizard stepper: four numbered stops (✓ when done) and "Step 2 of 4 · name".
			// Numbers, not a thin slideshow bar: people swiped sideways when it looked like stories.
			prog.hidden = false;
			prog.innerHTML = '';
			var list = document.createElement( 'ol' ); list.className = 'st-gs-list';
			[ 1, 2, 3, 4 ].forEach( function ( k ) {
				var li = document.createElement( 'li' );
				li.className = k < n ? 'is-done' : ( k === n ? 'is-now' : '' );
				if ( k === n ) { li.setAttribute( 'aria-current', 'step' ); }
				// Steps already done can be tapped to go back to them.
				var mark = document.createElement( k < n ? 'a' : 'span' ); mark.className = 'st-gs-mark'; mark.textContent = k < n ? '✓' : String( k );
				var nm = document.createElement( 'span' ); nm.className = 'st-gs-name'; nm.textContent = names[ k ];
				if ( k < n ) { mark.href = '#gs-' + firstOf[ k ]; mark.setAttribute( 'aria-label', ( T.backTo || 'Back to step %1$s: %2$s' ).replace( '%1$s', k ).replace( '%2$s', names[ k ] ) ); nm.hidden = true; } else { mark.setAttribute( 'aria-hidden', 'true' ); }
				li.appendChild( mark ); li.appendChild( nm );
				list.appendChild( li );
			} );
			var now = document.createElement( 'p' ); now.className = 'st-gs-now';
			now.textContent = ( T.stepOf || 'Step %1$s of 4' ).replace( '%1$s', n ) + ' · ' + names[ n ];
			prog.appendChild( list ); prog.appendChild( now );
			if ( focus ) { var h = cur.querySelector( 'h2' ); h.setAttribute( 'tabindex', '-1' ); h.focus(); window.scrollTo( 0, Math.max( 0, gs.getBoundingClientRect().top + window.scrollY - 80 ) ); }
		};
		var resumed = gs.querySelector( '[data-gs-resumed]' );
		window.addEventListener( 'hashchange', function () { if ( /^#gs-/.test( location.hash ) || ! location.hash ) { if ( resumed ) { resumed.hidden = true; } show( true ); } } );
		// Older links from the welcome page (?have=yes|no): skip the first question.
		try { var have = new URLSearchParams( location.search ).get( 'have' ); if ( ! location.hash && ( 'yes' === have || 'no' === have ) ) { history.replaceState( null, '', '#gs-' + ( 'yes' === have ? 'check' : 'host' ) ); } } catch ( e ) {}
		// Coming back later: open where you stopped, with a way to start again.
		try {
			var saved = mem.get( 'stubli-gs-step' );
			if ( ! location.hash && saved && where[ saved ] && 'start' !== saved ) { history.replaceState( null, '', '#gs-' + saved ); if ( resumed ) { resumed.hidden = false; } }
		} catch ( e ) {}
		var restart = gs.querySelector( '[data-gs-restart]' );
		if ( restart ) { restart.addEventListener( 'click', function () { mem.set( 'stubli-gs-step', 'start' ); } ); }
		show( false );
		// The browser jumps to #gs-… on load, past the checklist and any invite or welcome-back note: start at the top instead.
		window.addEventListener( 'load', function () { if ( /^#gs-/.test( location.hash ) ) { window.scrollTo( 0, 0 ); setTimeout( function () { window.scrollTo( 0, 0 ); }, 60 ); } } );
		var invForm = gs.querySelector( '[data-gs-invite-form]' );
		if ( invForm ) {
			invForm.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var err = invForm.querySelector( '.st-error' );
				if ( ! keepInvite( invForm.link.value ) ) { err.textContent = T.badInvite || 'That doesn\'t look like an invite link. It looks like theirname.com/invite/?t=… Ask your friend to send it again if you can\'t find it.'; err.hidden = false; invForm.link.focus(); return; }
				err.hidden = true;
				location.hash = '#gs-start';
			} );
		}
		// "Type your address" → open that page on the visitor's own WordPress.
		gs.querySelectorAll( '[data-gs-site]' ).forEach( function ( f ) {
			f.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var err = f.querySelector( '.st-error' ), v = ( f.addr.value || '' ).trim();
				if ( ! /^https?:\/\//i.test( v ) ) { v = 'https://' + v; }
				var u;
				try { u = new URL( v ); } catch ( x ) { u = null; }
				if ( ! u || u.hostname.indexOf( '.' ) < 1 ) { err.textContent = T.badAddress || 'That doesn\'t look like a web address. Try something like yourname.com.'; err.hidden = false; f.addr.focus(); return; }
				err.hidden = true;
				var base = u.origin + u.pathname.replace( /\/(wp-admin|wp-login\.php|app).*$/, '' ).replace( /\/+$/, '' );
				var path = f.getAttribute( 'data-path' );
				// Opening the setup: the friend's invite comes along, so the setup can use it.
				if ( invite && 0 === path.indexOf( 'app/' ) ) { path = 'app/?stubli_invite=' + encodeURIComponent( invite.url ) + path.slice( 4 ); }
				window.open( base + '/' + path, '_blank', 'noopener' );
			} );
		} );
		// WordPress.com: ask the address once, then link to that site's own Install
		// button (no site picker) and notice by itself when Stubli has arrived.
		var wp = gs.querySelector( '[data-gs-wpcom]' );
		var siteOf = function ( v ) {
			v = String( v || '' ).trim();
			if ( ! v ) { return null; }
			if ( ! /^https?:\/\//i.test( v ) ) { v = 'https://' + v; }
			var u; try { u = new URL( v ); } catch ( x ) { return null; }
			if ( u.hostname.indexOf( '.' ) < 1 ) { return null; }
			return { host: u.hostname.replace( /^www\./, '' ), base: u.protocol + '//' + u.host + u.pathname.replace( /\/(wp-admin|wp-login\.php|app).*$/, '' ).replace( /\/+$/, '' ) };
		};
		var savedSite = siteOf( mem.get( 'stubli-gs-site' ) );
		if ( savedSite ) { gs.querySelectorAll( '[data-gs-site] input[name="addr"]' ).forEach( function ( i ) { if ( ! i.value ) { i.value = savedSite.host; } } ); }
		if ( wp ) {
			var find = wp.querySelector( '[data-gs-find]' ), found = wp.querySelector( '[data-gs-found]' ), site = null, checking = false;
			var setState = function ( on ) {
				found.querySelector( '[data-gs-state="add"]' ).hidden = on;
				found.querySelector( '[data-gs-state="on"]' ).hidden = ! on;
			};
			// Is Stubli on that site yet? Its public REST index lists stubli/v1.
			var check = function () {
				if ( ! site || checking ) { return; }
				checking = true;
				fetch( site.base + '/wp-json/', { credentials: 'omit' } ).then( function ( r ) { return r.json(); } ).then( function ( j ) {
					setState( !! ( j && j.namespaces && j.namespaces.indexOf( 'stubli/v1' ) > -1 ) );
				} ).catch( function () {} ).then( function () { checking = false; } );
			};
			var paintSite = function () {
				find.hidden = !! site; found.hidden = ! site;
				if ( ! site ) { return; }
				found.querySelector( '[data-gs-host]' ).textContent = site.host;
				found.querySelector( '[data-gs-add]' ).href = 'https://wordpress.com/plugins/stubli/' + encodeURIComponent( site.host );
				var open = site.base + '/app/' + ( invite ? '?stubli_invite=' + encodeURIComponent( invite.url ) : '' ) + '#setup';
				found.querySelector( '[data-gs-open]' ).href = open;
				setState( false );
				check();
			};
			find.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var err = find.querySelector( '.st-error' ), s = siteOf( find.addr.value );
				if ( ! s ) { err.textContent = T.badAddress || 'That doesn\'t look like a web address. Try something like yourname.wordpress.com.'; err.hidden = false; find.addr.focus(); return; }
				err.hidden = true; site = s; mem.set( 'stubli-gs-site', s.base );
				gs.querySelectorAll( '[data-gs-site] input[name="addr"]' ).forEach( function ( i ) { i.value = s.host; } );
				paintSite();
			} );
			found.querySelector( '[data-gs-change]' ).addEventListener( 'click', function () { site = null; paintSite(); find.addr.focus(); } );
			// Back from WordPress.com (tab switch or the Back button): look again.
			document.addEventListener( 'visibilitychange', function () { if ( 'visible' === document.visibilityState ) { check(); } } );
			window.addEventListener( 'pageshow', check );
			if ( savedSite ) { site = savedSite; find.addr.value = savedSite.host; paintSite(); }
		}
	}

	/* Carousel: "1 of N", dots, arrow keys. */
	document.querySelectorAll( '[data-st-carousel]' ).forEach( function ( c ) {
		var track = c.querySelector( '.st-carousel-track' );
		var slides = track.children;
		var count = c.querySelector( '.st-carousel-count' );
		var dots = c.querySelectorAll( '.st-dots span' );
		if ( slides.length < 2 ) { return; }
		var current = -1;
		function update() {
			var i = Math.round( track.scrollLeft / Math.max( 1, track.clientWidth ) );
			i = Math.max( 0, Math.min( slides.length - 1, i ) );
			if ( i === current ) { return; }
			current = i;
			if ( count ) { count.textContent = ( T.of || '%1$d of %2$d' ).replace( '%1$d', i + 1 ).replace( '%2$d', slides.length ); }
			dots.forEach( function ( d, n ) { d.classList.toggle( 'is-on', n === i ); } );
		}
		track.addEventListener( 'scroll', function () { window.requestAnimationFrame( update ); }, { passive: true } );
		track.addEventListener( 'keydown', function ( e ) {
			if ( e.key !== 'ArrowRight' && e.key !== 'ArrowLeft' ) { return; }
			e.preventDefault();
			var next = Math.max( 0, Math.min( slides.length - 1, current + ( e.key === 'ArrowRight' ? 1 : -1 ) ) );
			track.scrollTo( { left: next * track.clientWidth, behavior: matchMedia( '(prefers-reduced-motion: reduce)' ).matches ? 'auto' : 'smooth' } );
		} );
		update();
	} );

	/* Full screen: tap or click a photo to see it as large as the screen allows, at
	   full size. Swipe or arrow keys for the next photo; close with ✕, Esc, Back or
	   a swipe down. Pinch to zoom is the browser's own. */
	var lb = null;
	function lbClose( fromHistory ) {
		if ( ! lb ) { return; }
		var o = lb; lb = null;
		document.removeEventListener( 'keydown', o.onKey, true );
		o.el.remove();
		document.documentElement.classList.remove( 'st-lb-open' );
		if ( ! fromHistory && history.state && history.state.stLb ) { history.back(); }
		if ( o.from && o.from.focus ) { o.from.focus( { preventScroll: true } ); }
	}
	window.addEventListener( 'popstate', function () { if ( lb ) { lbClose( true ); } } );
	function lbOpen( btn ) {
		var c = btn.closest( '[data-st-carousel]' );
		if ( c && c.classList.contains( 'has-note' ) && ! c.classList.contains( 'is-revealed' ) ) { return; }
		var all = Array.prototype.slice.call( ( c || document ).querySelectorAll( '[data-st-zoom]' ) );
		var start = Math.max( 0, all.indexOf( btn ) ), n = all.length;
		var el = document.createElement( 'div' );
		el.className = 'st-lb'; el.setAttribute( 'role', 'dialog' ); el.setAttribute( 'aria-modal', 'true' );
		var track = document.createElement( 'div' ); track.className = 'st-lb-track';
		all.forEach( function ( b, i ) {
			var f = document.createElement( 'figure' ), img = document.createElement( 'img' ), small = b.querySelector( 'img' );
			img.alt = b.getAttribute( 'data-alt' ) || '';
			img.decoding = 'async';
			// Show the picture already on the page at once, then swap in the full-size file.
			if ( small ) { img.src = small.currentSrc || small.src; }
			var full = new Image(); full.onload = function () { img.src = full.src; }; if ( Math.abs( i - start ) <= 1 ) { full.src = b.getAttribute( 'data-st-zoom' ); } else { img.setAttribute( 'data-full', b.getAttribute( 'data-st-zoom' ) ); img._full = full; }
			f.appendChild( img ); track.appendChild( f );
		} );
		var mk = function ( cls, label, svg ) { var b = document.createElement( 'button' ); b.type = 'button'; b.className = cls; b.setAttribute( 'aria-label', label ); b.innerHTML = svg; return b; };
		var ico = function ( d ) { return '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="' + d + '"/></svg>'; };
		var close = mk( 'st-lb-close', T.close || 'Close', ico( 'M6 6l12 12M18 6L6 18' ) );
		var count = document.createElement( 'p' ); count.className = 'st-lb-count'; count.setAttribute( 'aria-live', 'polite' );
		el.appendChild( track ); el.appendChild( close );
		var prev = null, next = null;
		if ( n > 1 ) {
			prev = mk( 'st-lb-nav st-lb-prev', T.prevPhoto || 'Previous photo', ico( 'M15 5l-7 7 7 7' ) );
			next = mk( 'st-lb-nav st-lb-next', T.nextPhoto || 'Next photo', ico( 'M9 5l7 7-7 7' ) );
			el.appendChild( prev ); el.appendChild( next ); el.appendChild( count );
		}
		document.body.appendChild( el );
		document.documentElement.classList.add( 'st-lb-open' );
		var reduce = matchMedia( '(prefers-reduced-motion: reduce)' ).matches, cur = -1;
		var go = function ( i, smooth ) { i = Math.max( 0, Math.min( n - 1, i ) ); track.scrollTo( { left: i * track.clientWidth, behavior: smooth && ! reduce ? 'smooth' : 'auto' } ); };
		var update = function () {
			var i = Math.max( 0, Math.min( n - 1, Math.round( track.scrollLeft / Math.max( 1, track.clientWidth ) ) ) );
			if ( i === cur ) { return; }
			cur = i;
			el.setAttribute( 'aria-label', ( T.photoOf || 'Photo %1$d of %2$d' ).replace( '%1$d', i + 1 ).replace( '%2$d', n ) );
			if ( n > 1 ) { count.textContent = ( T.of || '%1$d of %2$d' ).replace( '%1$d', i + 1 ).replace( '%2$d', n ); prev.disabled = i === 0; next.disabled = i === n - 1; }
			// Load the full-size files next to this one.
			[ i - 1, i, i + 1 ].forEach( function ( k ) { var im = track.children[ k ] && track.children[ k ].firstChild; if ( im && im._full && ! im._full.src ) { im._full.src = im.getAttribute( 'data-full' ); } } );
		};
		track.addEventListener( 'scroll', function () { window.requestAnimationFrame( update ); }, { passive: true } );
		go( start, false ); update();
		close.addEventListener( 'click', function () { lbClose( false ); } );
		if ( prev ) { prev.addEventListener( 'click', function () { go( cur - 1, true ); } ); next.addEventListener( 'click', function () { go( cur + 1, true ); } ); }
		// A tap on the dark space around the photo closes, like most viewers.
		el.addEventListener( 'click', function ( e ) { if ( e.target === el || e.target.tagName === 'FIGURE' ) { lbClose( false ); } } );
		// Swipe down to close.
		var y0 = null, x0 = 0;
		track.addEventListener( 'touchstart', function ( e ) { if ( e.touches.length === 1 && ( ! window.visualViewport || window.visualViewport.scale <= 1.01 ) ) { y0 = e.touches[ 0 ].clientY; x0 = e.touches[ 0 ].clientX; } else { y0 = null; } }, { passive: true } );
		track.addEventListener( 'touchend', function ( e ) { if ( y0 === null ) { return; } var t = e.changedTouches[ 0 ], dy = t.clientY - y0, dx = Math.abs( t.clientX - x0 ); y0 = null; if ( dy > 90 && dx < dy / 2 ) { lbClose( false ); } }, { passive: true } );
		var onKey = function ( e ) {
			if ( e.key === 'Escape' ) { e.preventDefault(); lbClose( false ); return; }
			if ( e.key === 'ArrowRight' || e.key === 'ArrowLeft' ) { e.preventDefault(); go( cur + ( e.key === 'ArrowRight' ? 1 : -1 ), true ); return; }
			if ( e.key === 'Tab' ) {
				// Keep the keyboard inside the viewer.
				var f = Array.prototype.filter.call( el.querySelectorAll( 'button' ), function ( b ) { return ! b.disabled; } );
				var a = f.indexOf( document.activeElement );
				e.preventDefault();
				f[ ( a + ( e.shiftKey ? -1 : 1 ) + f.length ) % f.length ].focus();
			}
		};
		document.addEventListener( 'keydown', onKey, true );
		lb = { el: el, from: btn, onKey: onKey };
		try { history.pushState( { stLb: 1 }, '' ); } catch ( x ) {}
		close.focus( { preventScroll: true } );
		var onResize = function () { if ( lb && lb.el === el ) { go( cur, false ); } else { window.removeEventListener( 'resize', onResize ); } };
		window.addEventListener( 'resize', onResize );
	}
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-st-zoom]' );
		if ( ! b ) { return; }
		e.preventDefault();
		lbOpen( b );
	} );

	/* Content note: blurred until the visitor chooses to look. */
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-st-reveal]' );
		if ( ! b ) { return; }
		var c = b.closest( '[data-st-carousel]' );
		c.classList.add( 'is-revealed' );
		var track = c.querySelector( '.st-carousel-track' );
		if ( track ) { track.focus(); }
	} );

	/* Video: nothing loads from the video site until play is pressed. */
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '.st-video-play' );
		if ( ! b ) { return; }
		var box = b.closest( '[data-st-video]' );
		var f = document.createElement( 'iframe' );
		f.src = box.getAttribute( 'data-st-video' );
		f.allow = 'autoplay; fullscreen; picture-in-picture';
		f.allowFullscreen = true;
		f.title = b.getAttribute( 'aria-label' ) || 'Video';
		box.replaceChildren( f );
	} );

	/* From your own Stubli: remember the address and go to that site. */
	document.querySelectorAll( '[data-st-remote]' ).forEach( function ( form ) {
		var input = form.querySelector( 'input' );
		var err = form.querySelector( '.st-error' );
		var saved = store.get( 'stubli-home' );
		if ( saved && ! input.value ) { input.value = saved; }
		input.addEventListener( 'input', function () { err.hidden = true; input.removeAttribute( 'aria-invalid' ); } );
		input.setAttribute( 'type', 'text' );
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var raw = input.value.trim();
			if ( ! /^https?:\/\//i.test( raw ) ) { raw = 'https://' + raw; }
			var url;
			try { url = new URL( raw ); } catch ( x ) { url = null; }
			if ( ! url || url.hostname.indexOf( '.' ) < 1 && url.hostname !== 'localhost' && ! /^\d+\.\d+\.\d+\.\d+$/.test( url.hostname ) ) {
				err.textContent = T.badAddress || 'That doesn\'t look like a website address.';
				err.hidden = false;
				input.setAttribute( 'aria-invalid', 'true' );
				input.focus();
				return;
			}
			var home = url.origin + url.pathname.replace( /\/+$/, '' );
			store.set( 'stubli-home', url.host + url.pathname.replace( /\/+$/, '' ) );
			var dest = home + '/app/?act=1&do=' + encodeURIComponent( form.getAttribute( 'data-do' ) ) + '&url=' + encodeURIComponent( form.getAttribute( 'data-target' ) );
			if ( form.getAttribute( 'data-invite' ) ) { dest += '&invite=' + encodeURIComponent( form.getAttribute( 'data-invite' ) ); }
			if ( form.getAttribute( 'data-p' ) && form.getAttribute( 'data-p' ) !== '-1' ) { dest += '&p=' + encodeURIComponent( form.getAttribute( 'data-p' ) ); }
			window.location.href = dest;
		} );
	} );
	/* Feedback form on stubli.app. */
	document.querySelectorAll( '[data-st-feedback]' ).forEach( function ( form ) {
		var q = form.querySelector( '[data-st-q]' ), ta = form.querySelector( 'textarea' ), err = form.querySelector( '.st-error' ), btn = form.querySelector( 'button[type="submit"]' );
		form.querySelectorAll( 'input[name="kind"]' ).forEach( function ( r ) {
			r.addEventListener( 'change', function () { q.textContent = r.getAttribute( 'data-q' ); ta.placeholder = r.getAttribute( 'data-ph' ); } );
		} );
		var ua = navigator.userAgent;
		var device = ( /iPhone/.test( ua ) ? 'iPhone' : /iPad/.test( ua ) ? 'iPad' : /Android/.test( ua ) ? 'Android' : /Mac OS X/.test( ua ) ? 'Mac' : /Windows/.test( ua ) ? 'Windows' : /Linux/.test( ua ) ? 'Linux' : 'Other' ) + ' · ' +
			( /Edg\//.test( ua ) ? 'Edge' : /Firefox\//.test( ua ) ? 'Firefox' : /CriOS|Chrome\//.test( ua ) ? 'Chrome' : /Safari\//.test( ua ) ? 'Safari' : 'Browser' );
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			err.hidden = true;
			if ( ! ta.value.trim() ) { err.textContent = 'Write a few words first.'; err.hidden = false; ta.focus(); return; }
			var fd = new FormData( form );
			fd.set( 'device', device ); fd.set( 'version', form.getAttribute( 'data-version' ) || '' ); fd.set( 'source', 'web' );
			var shot = form.querySelector( 'input[type="file"]' );
			if ( shot && ( ! shot.files.length || shot.files[ 0 ].size > 8 * 1024 * 1024 ) ) { fd.delete( 'screenshot' ); }
			btn.disabled = true; btn.textContent = 'Sending…';
			fetch( form.getAttribute( 'data-url' ), { method: 'POST', body: fd, credentials: 'omit' } ).then( function ( r ) {
				return r.json().then( function ( d ) { if ( ! r.ok ) { throw new Error( ( d && d.message ) || 'The note didn\'t go through.' ); } } );
			} ).then( function () {
				form.hidden = true;
				btn.disabled = false; btn.textContent = 'Send feedback';
				var done = document.querySelector( '[data-st-feedback-done]' ); done.hidden = false; done.focus();
			} ).catch( function ( x ) {
				err.textContent = ( x && x.message ) || 'The note didn\'t go through. Try again in a moment.'; err.hidden = false;
				btn.disabled = false; btn.textContent = 'Send feedback';
			} );
		} );
	} );
}() );

/* Prompt cards behind the profile card: arrows, dots and swipe. */
( function () {
	document.querySelectorAll( '[data-st-stack]' ).forEach( function ( stack ) {
		var cards = Array.prototype.slice.call( stack.querySelectorAll( '[data-st-card]' ) );
		var nav = stack.parentNode.querySelector( '[data-st-stack-nav]' );
		if ( cards.length < 2 || ! nav ) { return; }
		var dots = nav.querySelectorAll( '.st-stack-dots span' ), status = nav.querySelector( '[data-st-stack-status]' ), i = 0;
		stack.classList.add( 'is-live' ); nav.hidden = false;
		function show( n, announce ) {
			i = ( n + cards.length ) % cards.length;
			cards.forEach( function ( c, k ) {
				var pos = ( k - i + cards.length ) % cards.length;
				c.setAttribute( 'data-pos', pos > 2 ? 'hide' : String( pos ) );
				if ( pos === 0 ) { c.removeAttribute( 'aria-hidden' ); c.inert = false; } else { c.setAttribute( 'aria-hidden', 'true' ); c.inert = true; }
			} );
			Array.prototype.forEach.call( dots, function ( d, k ) { d.classList.toggle( 'is-on', k === i ); } );
			if ( announce && status ) { status.textContent = ( i + 1 ) + ' / ' + cards.length + ': ' + ( cards[ i ].getAttribute( 'aria-label' ) || '' ); }
		}
		nav.querySelector( '[data-st-prev]' ).addEventListener( 'click', function () { show( i - 1, true ); } );
		nav.querySelector( '[data-st-next]' ).addEventListener( 'click', function () { show( i + 1, true ); } );
		var x0 = null, y0 = null;
		stack.addEventListener( 'touchstart', function ( e ) { x0 = e.touches[ 0 ].clientX; y0 = e.touches[ 0 ].clientY; }, { passive: true } );
		stack.addEventListener( 'touchend', function ( e ) {
			if ( x0 === null ) { return; }
			var dx = e.changedTouches[ 0 ].clientX - x0, dy = e.changedTouches[ 0 ].clientY - y0; x0 = null;
			if ( Math.abs( dx ) > 40 && Math.abs( dx ) > Math.abs( dy ) ) { show( dx < 0 ? i + 1 : i - 1, true ); }
		} );
		show( 0, false );
	} );
}() );


/* Reply to a prompt card: tabs, and the guest note form. */
( function () {
	var tabs = document.querySelector( '[data-st-note-tabs]' );
	if ( tabs ) {
		var btns = Array.prototype.slice.call( tabs.querySelectorAll( '[role=tab]' ) );
		var pick = function ( b, focus ) {
			btns.forEach( function ( x ) {
				var on = x === b;
				x.setAttribute( 'aria-selected', on ? 'true' : 'false' );
				x.tabIndex = on ? 0 : -1;
				document.getElementById( x.getAttribute( 'aria-controls' ) ).hidden = ! on;
			} );
			if ( focus ) { b.focus(); }
		};
		btns.forEach( function ( b, k ) {
			b.addEventListener( 'click', function () { pick( b ); } );
			b.addEventListener( 'keydown', function ( e ) {
				if ( e.key === 'ArrowRight' || e.key === 'ArrowLeft' ) { e.preventDefault(); pick( btns[ ( k + ( e.key === 'ArrowRight' ? 1 : -1 ) + btns.length ) % btns.length ], true ); }
			} );
		} );
		pick( btns[ 0 ] );
	}
	var form = document.querySelector( '[data-st-note]' );
	if ( ! form ) { return; }
	var err = form.querySelector( '.st-error' ), btn = form.querySelector( 'button[type=submit]' );
	form.addEventListener( 'submit', function ( e ) {
		e.preventDefault();
		var get = function ( n ) { return ( form.elements[ n ] && form.elements[ n ].value || '' ).trim(); };
		var missing = ! get( 'text' ) ? 'text' : ! get( 'name' ) ? 'name' : '';
		if ( missing ) {
			err.textContent = form.getAttribute( 'data-need-' + missing ) || 'Write a few words first.';
			err.hidden = false; form.elements[ missing ].focus(); return;
		}
		err.hidden = true; btn.disabled = true; btn.textContent = 'Sending…';
		fetch( form.getAttribute( 'data-url' ), {
			method: 'POST', headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify( { text: get( 'text' ), name: get( 'name' ), contact: get( 'contact' ), website: get( 'website' ), prompt: form.getAttribute( 'data-prompt' ) } )
		} ).then( function ( r ) { return r.json().then( function ( d ) { return { ok: r.ok, d: d }; } ); } ).then( function ( res ) {
			if ( ! res.ok ) { throw new Error( ( res.d && res.d.message ) || '' ); }
			form.hidden = true;
			var done = document.querySelector( '[data-st-note-done]' ); done.hidden = false; done.focus();
			if ( tabs ) { tabs.hidden = true; }
		} ).catch( function ( x ) {
			btn.disabled = false; btn.textContent = 'Send note';
			err.textContent = x.message || 'The note didn\'t go through. Check your connection and try again.'; err.hidden = false;
		} );
	} );
}() );


/* Guest book: the owner pins or unpins an entry right on the page. */
( function () {
	var list = document.querySelector( '[data-st-gb]' );
	if ( ! list ) { return; }
	list.addEventListener( 'click', function ( e ) {
		var b = e.target.closest( '[data-st-gb-pin]' );
		if ( ! b || b.disabled ) { return; }
		var on = b.getAttribute( 'data-pinned' ) !== '1';
		b.disabled = true;
		fetch( list.getAttribute( 'data-api' ) + b.getAttribute( 'data-st-gb-pin' ) + '/pin', { method: on ? 'POST' : 'DELETE', credentials: 'same-origin', headers: { 'X-WP-Nonce': list.getAttribute( 'data-nonce' ) } } )
			.then( function ( r ) { if ( ! r.ok ) { throw new Error( 'no' ); } location.reload(); } )
			.catch( function () { b.disabled = false; } );
	} );
}() );



/* Latest, on wider screens: as many of the newest posts as fill the card
   beside the profile, whole rows only. */
( function () {
	var box = document.querySelector( '[data-st-latest]' );
	if ( ! box ) { return; }
	var fit = function () {
		var rows = box.querySelectorAll( '.st-latest-row' );
		Array.prototype.forEach.call( rows, function ( r ) { r.classList.remove( 'is-cut' ); } );
		if ( getComputedStyle( box ).position !== 'absolute' ) { return; }
		var h = box.clientHeight;
		Array.prototype.forEach.call( rows, function ( r ) { if ( r.offsetTop + r.offsetHeight > h + 1 ) { r.classList.add( 'is-cut' ); } } );
	};
	fit();
	window.addEventListener( 'resize', fit );
	window.addEventListener( 'load', fit );
	if ( window.ResizeObserver ) { new ResizeObserver( fit ).observe( box ); }
}() );


/* "and 4 more this week" under Latest opens the This week panel (2 Nov 2026).
   Closes with the ✕, a tap outside it, Escape, or the phone's Back button. */
( function () {
	var open = document.querySelector( '[data-st-week-open]' ), box = document.getElementById( 'st-week' );
	if ( ! open || ! box || typeof box.showModal !== 'function' ) { return; }
	var pushed = false;
	open.addEventListener( 'click', function ( e ) {
		e.preventDefault();
		box.showModal();
		try { history.pushState( { stWeek: 1 }, '' ); pushed = true; } catch ( err ) { pushed = false; }
	} );
	var shut = function () { if ( box.open ) { box.close(); } };
	box.querySelector( '[data-st-week-close]' ).addEventListener( 'click', shut );
	box.addEventListener( 'click', function ( e ) { if ( e.target === box ) { shut(); } } );
	box.addEventListener( 'close', function () {
		open.focus();
		if ( pushed ) { pushed = false; history.back(); }
	} );
	window.addEventListener( 'popstate', function () { if ( box.open ) { pushed = false; box.close(); } } );
	// Coming back from a post with the browser's Back button: start closed.
	window.addEventListener( 'pageshow', function ( e ) { if ( e.persisted && box.open ) { pushed = false; box.close(); } } );
}() );

/* stubli.app's home page: while a "Make your Stubli" card is on screen,
 * the same button in the top bar steps aside, so it's never shown twice. */
( function () {
	var join = document.querySelector( '.st-top-join' );
	var cards = document.querySelectorAll( '.st-welcome-card' );
	if ( ! join || ! cards.length || ! ( 'IntersectionObserver' in window ) ) {
		return;
	}
	var seen = new Set();
	var io = new IntersectionObserver( function ( entries ) {
		entries.forEach( function ( e ) { if ( e.isIntersecting ) { seen.add( e.target ); } else { seen.delete( e.target ); } } );
		join.classList.toggle( 'is-quiet', seen.size > 0 );
	} );
	Array.prototype.forEach.call( cards, function ( c ) { io.observe( c ); } );
}() );


/* The guest book's one form (0.2.130): sign in public, or tick Private to send a note only the owner sees.
   Messages come from the page, so they're translated. */
( function () {
	var form = document.querySelector( '[data-st-gb-write]' );
	if ( ! form ) { return; }
	var err = form.querySelector( '.st-error' ), btn = form.querySelector( 'button[type=submit]' ), box = form.querySelector( '[data-st-gb-private]' );
	var wrap = form.parentNode, text = form.elements.text;
	var isPrivate = function () { return box ? box.checked : form.hasAttribute( 'data-private' ); };
	var show = function () {
		var p = isPrivate();
		form.querySelector( '[data-st-gb-public]' ).hidden = p;
		form.querySelector( '[data-st-gb-privnote]' ).hidden = ! p;
		var a = wrap.querySelector( '[data-st-gb-own-public]' ), b = wrap.querySelector( '[data-st-gb-own-private]' );
		if ( a ) { a.hidden = p; } if ( b ) { b.hidden = ! p; }
		text.maxLength = p ? 1000 : 500;
		btn.textContent = btn.getAttribute( p ? 'data-label-private' : 'data-label-public' );
	};
	if ( box ) { box.addEventListener( 'change', function () { err.hidden = true; show(); } ); }
	// The envelope next to Follow lands here with Private ticked: open and start typing.
	if ( wrap.open && location.hash === '#write' ) { var go = function () { wrap.scrollIntoView( { block: 'start' } ); text.focus( { preventScroll: true } ); }; if ( document.readyState === 'complete' ) { go(); } else { window.addEventListener( 'load', go ); } }
	form.addEventListener( 'submit', function ( e ) {
		e.preventDefault();
		var get = function ( n ) { return ( form.elements[ n ] && form.elements[ n ].value || '' ).trim(); };
		var missing = ! get( 'text' ) ? 'text' : ! get( 'name' ) ? 'name' : '';
		if ( missing ) {
			err.textContent = form.getAttribute( 'data-need-' + missing ); err.hidden = false; form.elements[ missing ].focus(); return;
		}
		var p = isPrivate();
		err.hidden = true; btn.disabled = true; btn.textContent = form.getAttribute( 'data-sending' );
		var body = p ? { text: get( 'text' ), name: get( 'name' ), contact: get( 'contact' ), website: get( 'website' ), prompt: -1 }
			: { text: get( 'text' ), name: get( 'name' ), from: get( 'from' ), website: get( 'website' ) };
		fetch( form.getAttribute( p ? 'data-note-url' : 'data-sign-url' ), {
			method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( body )
		} ).then( function ( r ) { return r.json().then( function ( d ) { return { ok: r.ok, d: d }; } ); } ).then( function ( res ) {
			if ( ! res.ok ) { throw new Error( ( res.d && res.d.message ) || '' ); }
			form.hidden = true;
			Array.prototype.forEach.call( wrap.querySelectorAll( '.st-gb-own' ), function ( x ) { x.hidden = true; } );
			var done = wrap.querySelector( p ? '[data-st-gb-sent]' : '[data-st-gb-done]' ); done.hidden = false; done.focus();
		} ).catch( function ( x ) {
			btn.disabled = false; show();
			err.textContent = x.message || form.getAttribute( 'data-failed' ); err.hidden = false;
		} );
	} );
}() );
