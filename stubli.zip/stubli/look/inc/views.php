<?php
/**
 * The page views, drawn by the stubli/view block.
 *
 * @package Stubli
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render callback for stubli/view.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function stubli_render_view( $attrs ) {
	$view = stubli_view_name( isset( $attrs['view'] ) ? (string) $attrs['view'] : 'profile' );
	ob_start();
	stubli_print_view( $view );
	return (string) ob_get_clean();
}

/**
 * Which view this request shows.
 *
 * @param string $view The view asked for.
 * @return string
 */
function stubli_view_name( $view ) {
	if ( get_query_var( 'stubli_journal' ) ) {
		$view = 'journal';
	} elseif ( get_query_var( 'stubli_links' ) ) {
		$view = 'links';
	} elseif ( get_query_var( 'stubli_invite' ) ) {
		$view = 'invite';
	} elseif ( get_query_var( 'stubli_remote' ) ) {
		$view = 'remote';
	} elseif ( 'page' === $view && stubli_has_plugin() && is_page( \Stubli\Guestbook::page_id() ) ) {
		$view = 'guestbook';
	}
	return $view;
}

/**
 * Print a view straight to the page (the built-in look's page template).
 *
 * @param string $view View name, already resolved by stubli_view_name().
 */
function stubli_print_view( $view ) {
	echo '<div class="st-app">';
	switch ( $view ) {
		case 'single':
			stubli_view_single();
			break;
		case 'journal':
			stubli_view_journal();
			break;
		case 'guestbook':
			stubli_view_guestbook();
			break;
		case 'links':
			stubli_view_links();
			break;
		case 'remote':
			stubli_view_remote();
			break;
		case 'invite':
			stubli_view_invite();
			break;
		case 'page':
			stubli_view_page();
			break;
		case 'notfound':
			stubli_view_notfound();
			break;
		default:
			stubli_view_profile();
	}
	stubli_footer();
	echo '</div>';
}

/* ───────────────────────── Shared pieces ───────────────────────── */

/**
 * Top bar: site address (or a back link), project pages, reading mode.
 *
 * @param string $back_url  Optional back link.
 * @param string $back_text Its label.
 */
function stubli_topbar( $back_url = '', $back_text = '' ) {
	$pages = get_pages(
		array(
			'sort_column' => 'menu_order,post_title',
			'exclude'     => stubli_has_plugin() ? array( \Stubli\Guestbook::page_id() ) : array(),
		)
	);
	// Pages ordered 90 or later stay out of the top bar (stubli.app keeps Privacy in its footer).
	// WordPress's starter "Sample Page" never shows (audit #12).
	$pages = array_values( array_filter( $pages, static fn( $p ) => (int) $p->menu_order < 90 && 'sample-page' !== $p->post_name ) );
	/**
	 * Filters the pages listed in the top bar.
	 *
	 * @param WP_Post[] $pages Pages, in order.
	 */
	$pages = (array) apply_filters( 'stubli_top_pages', $pages );
	$hub   = class_exists( '\\Stubli\\Feedback' ) && \Stubli\Feedback::is_hub();
	if ( $hub ) {
		// stubli.app's top bar: how it works, and the way in.
		// In this order: the way in, how it works, help (then the reading mode).
		$order = array( 'get-started', 'how-it-works', 'help' );
		$help  = get_page_by_path( 'help' );
		if ( $help && 'publish' === $help->post_status ) {
			$pages[] = $help;
		}
		$pages = array_values( array_filter( $pages, static fn( $p ) => in_array( $p->post_name, $order, true ) ) );
		usort( $pages, static fn( $a, $b ) => array_search( $a->post_name, $order, true ) <=> array_search( $b->post_name, $order, true ) );
	}
	$welcome = $hub ? get_page_by_path( 'welcome' ) : null;
	$join    = $welcome && 'publish' === $welcome->post_status ? ( function_exists( 'stubli_is_pitch' ) && stubli_is_pitch() ? '#start' : get_permalink( $welcome ) ) : '';
	?>
	<header class="st-top<?php echo $hub ? ' st-top-brand' : ''; ?>">
		<?php if ( $back_url ) : ?>
			<a class="st-top-back" href="<?php echo esc_url( $back_url ); ?>"><?php echo wp_kses( stubli_icon( 'back', 22 ), stubli_allowed_html() ); ?><span><?php echo esc_html( $back_text ); ?></span></a>
		<?php else : ?>
			<?php if ( $hub ) : ?>
				<a class="st-top-host st-top-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Stubli (beta), home', 'stubli' ); ?>"><?php echo wp_kses( stubli_wordmark( true ), stubli_allowed_html() ); ?><span class="st-beta" aria-hidden="true"><?php esc_html_e( 'Beta', 'stubli' ); ?></span></a>
			<?php else : ?>
				<a class="st-top-host" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ); ?></a>
			<?php endif; ?>
		<?php endif; ?>
		<?php if ( $pages ) : ?>
			<nav class="st-top-pages" aria-label="<?php esc_attr_e( 'Pages', 'stubli' ); ?>">
				<?php foreach ( $pages as $page ) : ?>
					<a href="<?php echo esc_url( $hub && $join && 'get-started' === $page->post_name ? $join : get_permalink( $page ) ); ?>"<?php echo $hub && 'get-started' === $page->post_name ? ' class="st-top-join"' : ( $hub && 'help' === $page->post_name ? ' class="st-top-help"' : '' ); ?><?php echo is_page( $page->ID ) || ( 'help' === $page->post_name && function_exists( 'stubli_is_help' ) && stubli_is_help() ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $hub && 'get-started' === $page->post_name ? __( 'Make your Stubli', 'stubli' ) : ( $hub && 'how-it-works' === $page->post_name ? __( 'How it works', 'stubli' ) : get_the_title( $page ) ) ); ?></a>
				<?php endforeach; ?>
				<?php if ( $hub && function_exists( 'stubli_story_on' ) && stubli_story_on() ) : ?>
					<a class="st-top-join" href="<?php echo esc_url( stubli_story_url( 'join' ) ); ?>"><?php esc_html_e( 'Make your Stubli', 'stubli' ); ?></a>
				<?php endif; ?>
			</nav>
		<?php endif; ?>
		<button type="button" class="st-mode" data-st-mode aria-label="<?php esc_attr_e( 'Reading mode', 'stubli' ); ?>"><span class="st-mode-aa" aria-hidden="true">Aa</span> <span class="st-mode-label"><?php esc_html_e( 'Auto', 'stubli' ); ?></span></button>
	</header>
	<?php
}

/**
 * A small pill-shaped action inside a 44px hit area.
 *
 * @param string $url     Link.
 * @param string $label   Text.
 * @param string $variant primary | quiet.
 * @return string
 */
function stubli_pill( $url, $label, $variant = 'primary' ) {
	return sprintf( '<a class="st-pill st-pill-%3$s" href="%1$s"><span>%2$s</span></a>', esc_url( $url ), esc_html( $label ), esc_attr( $variant ) );
}

/**
 * The profile card and the Latest card.
 */
function stubli_profile_cards() {
	$p      = stubli_profile();
	$recent = stubli_latest_photos( 6 );
	$latest = $recent ? $recent[0] : null;
	?>
	<?php $prompts = ! empty( $p['prompts'] ) && is_array( $p['prompts'] ) ? $p['prompts'] : array(); ?>
	<div class="st-cards">
		<div class="st-stack-wrap">
		<div class="st-stack<?php echo $prompts ? ' has-cards' : ''; ?>" data-st-stack aria-roledescription="<?php esc_attr_e( 'cards', 'stubli' ); ?>">
		<?php $cover = (string) ( $p['cover'] ?? '' ); ?>
		<section class="st-card st-profile is-front<?php echo '' !== $cover ? ' has-cover' : ''; ?>" data-st-card aria-label="<?php esc_attr_e( 'About', 'stubli' ); ?>">
			<?php if ( '' !== $cover ) : ?>
				<div class="st-cover"><img src="<?php echo esc_url( $cover ); ?>" alt="" width="1800" height="600" decoding="async" fetchpriority="high"></div>
			<?php endif; ?>
			<div class="st-profile-head">
				<?php if ( ! empty( $p['avatar'] ) ) : ?>
					<img class="st-avatar" src="<?php echo esc_url( stubli_img_src( $p['avatar'] ), array( 'http', 'https', 'data' ) ); ?>" alt="" width="44" height="44">
				<?php endif; ?>
				<div class="st-profile-name">
					<h1><?php echo esc_html( $p['name'] ); ?><?php if ( ! empty( $p['pronouns'] ) ) : ?> <span class="st-pronouns"><?php echo esc_html( $p['pronouns'] ); ?></span><?php endif; ?></h1>
					<span class="st-muted"><?php echo esc_html( $p['host'] ); ?></span>
				</div>
				<?php
				if ( stubli_is_owner() ) {
					echo wp_kses( stubli_pill( home_url( '/app/' ), __( 'Open the app', 'stubli' ) ), stubli_allowed_html() );
				} else {
					echo wp_kses( stubli_pill( stubli_remote_url( 'follow', home_url( '/' ) ), __( 'Follow', 'stubli' ) ), stubli_allowed_html() );
				}
				?>
			</div>
			<?php if ( '' !== trim( $p['bio'] ) ) : ?>
				<p class="st-bio"><?php echo esc_html( $p['bio'] ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $p['on_break'] ) ) : ?>
				<p class="st-break"><?php /* translators: %s: name */ printf( esc_html__( '%s is taking a break from comments.', 'stubli' ), esc_html( $p['name'] ) ); ?></p>
			<?php endif; ?>
		</section>
		<?php foreach ( $prompts as $i => $card ) : ?>
			<section class="st-card st-prompt is-tone-<?php echo (int) $i % 4; ?>" data-st-card aria-label="<?php echo esc_attr( $card['q'] ); ?>">
				<p class="st-prompt-q"><?php echo esc_html( $card['q'] ); ?></p>
				<?php $len = function_exists( 'mb_strlen' ) ? mb_strlen( (string) $card['a'] ) : strlen( (string) $card['a'] ); ?>
				<p class="st-prompt-a<?php echo $len <= 28 ? ' is-short' : ( $len <= 80 ? ' is-mid' : '' ); ?>"><?php echo esc_html( $card['a'] ); ?></p>
				<?php if ( ! stubli_is_owner() && empty( $p['on_break'] ) ) : ?>
					<a class="st-pill st-pill-quiet st-prompt-reply" href="<?php echo esc_url( add_query_arg( 'p', (int) $i, stubli_remote_url( 'note', home_url( '/' ) ) ) ); ?>"><span><?php esc_html_e( 'Reply to this', 'stubli' ); ?></span></a>
				<?php endif; ?>
			</section>
		<?php endforeach; ?>
		</div>
		<?php if ( $prompts ) : ?>
			<div class="st-stack-nav" data-st-stack-nav hidden>
				<button type="button" class="st-stack-btn" data-st-prev aria-label="<?php esc_attr_e( 'Previous card', 'stubli' ); ?>"><?php echo wp_kses( stubli_icon( 'back', 18 ), stubli_allowed_html() ); ?></button>
				<span class="st-stack-dots" aria-hidden="true"><?php echo wp_kses( str_repeat( '<span></span>', count( $prompts ) + 1 ), stubli_allowed_html() ); ?></span>
				<button type="button" class="st-stack-btn" data-st-next aria-label="<?php /* translators: %s: name */ echo esc_attr( sprintf( __( 'Next card: more about %s', 'stubli' ), $p['name'] ) ); ?>"><?php echo wp_kses( stubli_icon( 'chev', 18 ), stubli_allowed_html() ); ?></button>
				<span class="st-sr" aria-live="polite" data-st-stack-status></span>
			</div>
		<?php endif; ?>
		</div>
		<?php if ( $latest ) : ?>
			<?php // On a phone: the newest post in one row. On a wider screen: as many of the last six as fill the card beside the profile, whole rows only. ?>
			<div class="st-card st-latest<?php echo count( $recent ) > 1 ? ' has-more' : ''; ?>">
				<p class="st-latest-h"><?php esc_html_e( 'Latest', 'stubli' ); ?></p>
				<div class="st-latest-rows" data-st-latest>
				<?php foreach ( $recent as $k => $r ) : ?>
					<?php
					$ids  = stubli_photo_ids( $r->ID );
					$coll = stubli_post_collection( $r->ID );
					?>
					<a class="st-latest-row" href="<?php echo esc_url( get_permalink( $r ) ); ?>">
						<?php echo wp_kses( $ids ? wp_get_attachment_image( $ids[0], 'thumbnail', false, array( 'class' => 'st-latest-img' . ( get_post_meta( $r->ID, '_stubli_content_note', true ) ? ' is-noted' : '' ), 'alt' => '', 'loading' => $k ? 'lazy' : 'eager' ) ) : '', stubli_allowed_html() ); ?>
						<span class="st-latest-text">
							<span class="st-muted"><?php if ( 0 === $k ) : ?><span class="st-latest-first"><?php /* translators: %s: when */ printf( esc_html__( 'Latest · %s', 'stubli' ), esc_html( stubli_gentle_date( $r ) ) ); ?></span><span class="st-latest-when"><?php echo esc_html( stubli_gentle_date( $r ) ); ?></span><?php else : ?><?php echo esc_html( stubli_gentle_date( $r ) ); ?><?php endif; ?></span>
							<span><?php echo esc_html( stubli_post_label( $r ) ); ?><?php if ( $coll ) : ?> <span class="st-muted"><?php /* translators: %s: collection */ printf( esc_html__( 'in %s', 'stubli' ), esc_html( stubli_collection_name( $coll ) ) ); ?></span><?php endif; ?></span>
						</span>
						<?php echo wp_kses( stubli_icon( 'chev', 18 ), stubli_allowed_html() ); ?>
					</a>
				<?php endforeach; ?>
				</div>
				<?php
				// Phones only (wider screens list the newest posts above): "and 4 more this week" opens a panel with them.
				$more = stubli_latest_more( $latest );
				if ( $more['count'] > 0 ) :
					?>
					<p class="st-latest-more"><a href="#st-week" data-st-week-open aria-haspopup="dialog">
					<?php
					/* translators: %s: how many more posts this week */
					echo esc_html( sprintf( _n( 'and %s more this week', 'and %s more this week', $more['count'], 'stubli' ), number_format_i18n( $more['count'] ) ) );
					?>
					</a></p>
					<dialog class="st-week" id="st-week" aria-labelledby="st-week-h">
						<div class="st-week-head">
							<h2 id="st-week-h"><?php esc_html_e( 'This week', 'stubli' ); ?></h2>
							<button type="button" class="st-week-close" data-st-week-close aria-label="<?php esc_attr_e( 'Close', 'stubli' ); ?>"><?php echo wp_kses( stubli_icon( 'close', 20 ), stubli_allowed_html() ); ?></button>
						</div>
						<ul class="st-week-list">
						<?php foreach ( array_slice( $more['posts'], 0, 5 ) as $r ) : ?>
							<?php
							$ids  = stubli_photo_ids( $r->ID );
							$coll = stubli_post_collection( $r->ID );
							?>
							<li><a class="st-latest-row" href="<?php echo esc_url( get_permalink( $r ) ); ?>">
								<?php echo wp_kses( $ids ? wp_get_attachment_image( $ids[0], 'thumbnail', false, array( 'class' => 'st-latest-img' . ( get_post_meta( $r->ID, '_stubli_content_note', true ) ? ' is-noted' : '' ), 'alt' => '', 'loading' => 'lazy' ) ) : '', stubli_allowed_html() ); ?>
								<span class="st-latest-text">
									<span class="st-muted"><?php echo esc_html( ucfirst( stubli_gentle_date( $r ) ) ); ?></span>
									<span><?php echo esc_html( stubli_post_label( $r ) ); ?><?php if ( $coll ) : ?> <span class="st-muted"><?php /* translators: %s: collection */ printf( esc_html__( 'in %s', 'stubli' ), esc_html( stubli_collection_name( $coll ) ) ); ?></span><?php endif; ?></span>
								</span>
								<?php echo wp_kses( stubli_icon( 'chev', 18 ), stubli_allowed_html() ); ?>
							</a></li>
						<?php endforeach; ?>
						</ul>
						<?php if ( $more['count'] > 5 && stubli_has_all() ) : ?>
							<p class="st-week-all"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'See everything in All', 'stubli' ); ?></a></p>
						<?php endif; ?>
					</dialog>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * The folder tabs: collections and Journal on the left, Guest book and
 * Favourites (Stubli green) on the right.
 *
 * @param int|string $active Term ID, or journal | guest | links.
 */
function stubli_tabs( $active ) {
	$collections = stubli_collections();
	$tabs        = array(
		'journal' => array( home_url( '/journal/' ), __( 'Journal', 'stubli' ), 'book' ),
		'guest'   => array( stubli_has_plugin() ? \Stubli\Guestbook::url() : '', __( 'Guest book', 'stubli' ), 'pen' ),
		'links'   => array( home_url( '/favourites/' ), __( 'Favourites', 'stubli' ), 'heart' ),
	);
	$icon_tab    = static function ( $key, $green ) use ( $tabs, $active ) {
		list( $url, $label, $icon ) = $tabs[ $key ];
		if ( ! $url ) {
			return;
		}
		$is = ( $active === $key );
		echo wp_kses(
			sprintf(
				'<a class="st-tab %1$s%2$s" href="%3$s"%4$s%5$s><span class="st-tab-face">%6$s<span class="st-tab-label">%7$s</span></span></a>',
				$green ? 'st-tab-green' : 'st-tab-plain',
				$is ? ' is-active' : ' st-tab-icon',
				esc_url( $url ),
				$is ? ' aria-current="page"' : '',
				$is ? '' : ' aria-label="' . esc_attr( $label ) . '" data-tip="' . esc_attr( $label ) . '"',
				stubli_icon( $icon, 18 ),
				esc_html( $label )
			),
			stubli_allowed_html()
		);
	};
	?>
	<nav class="st-tabs" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: name */ __( '%s\'s page', 'stubli' ), stubli_first_name() ) ); ?>">
		<div class="st-tabs-left">
			<div class="st-tabs-scroll" data-st-scroll>
				<?php if ( stubli_has_all() ) : ?>
					<?php $is = ( 0 === $active ); ?>
					<a class="st-tab st-tab-plain<?php echo $is ? ' is-active' : ''; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>"<?php echo $is ? ' aria-current="page"' : ''; ?>><span class="st-tab-face"><span class="st-tab-label"><?php esc_html_e( 'All', 'stubli' ); ?></span></span></a>
				<?php endif; ?>
				<?php foreach ( $collections as $term ) : ?>
					<?php $is = ( (int) $active === (int) $term->term_id ); ?>
					<a class="st-tab st-tab-plain<?php echo $is ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_category_link( $term ) ); ?>"<?php echo $is ? ' aria-current="page"' : ''; ?>><span class="st-tab-face"><span class="st-tab-label"><?php echo esc_html( stubli_collection_name( $term ) ); ?></span></span></a>
				<?php endforeach; ?>
			</div>
			<?php $icon_tab( 'journal', false ); ?>
		</div>
		<div class="st-tabs-right" role="group" aria-label="<?php esc_attr_e( 'Visit and connect', 'stubli' ); ?>">
			<?php $icon_tab( 'guest', true ); ?>
			<?php $icon_tab( 'links', true ); ?>
		</div>
	</nav>
	<?php
}

/**
 * The photo grid.
 *
 * @param WP_Query $q Photo posts.
 */
function stubli_grid( WP_Query $q ) {
	if ( ! $q->have_posts() ) {
		echo wp_kses( stubli_empty( 'photos' ), stubli_allowed_html() );
		return;
	}
	// The collection takes the shape of its first photo: landscape, square or portrait (the default).
	$shape = 'portrait';
	$first = stubli_tile_ids( $q->posts[0]->ID );
	if ( $first ) {
		$meta = wp_get_attachment_metadata( $first[0] );
		if ( ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
			$r     = (float) $meta['width'] / (float) $meta['height'];
			$shape = $r > 1.15 ? 'landscape' : ( $r >= 0.9 ? 'square' : 'portrait' );
		}
	}
	$size = 'portrait' === $shape ? 'stubli-tile' : 'medium_large';
	echo '<ul class="st-grid' . ( 'portrait' !== $shape ? ' is-' . esc_attr( $shape ) : '' ) . '" role="list">';
	foreach ( $q->posts as $post ) {
		if ( stubli_is_filed_entry( $post->ID ) ) {
			stubli_entry_tile( $post, $size );
			continue;
		}
		$ids  = stubli_photo_ids( $post->ID );
		$note = (string) get_post_meta( $post->ID, '_stubli_content_note', true );
		$alt  = $ids ? (string) get_post_meta( $ids[0], '_wp_attachment_image_alt', true ) : '';
		echo '<li><a class="st-tile" href="' . esc_url( get_permalink( $post ) ) . '">';
		echo '<span class="st-tile-photo' . ( $note ? ' has-note' : '' ) . '">';
		if ( $ids ) {
			echo wp_kses( wp_get_attachment_image( $ids[0], $size, false, array( 'alt' => $note ? '' : $alt, 'loading' => 'lazy', 'sizes' => '(min-width: 1280px) 240px, (min-width: 768px) 30vw, 46vw' ) ), stubli_allowed_html() );
		}
		if ( count( $ids ) > 1 ) {
			echo wp_kses( '<span class="st-badge">' . stubli_icon( 'stack', 14 ) . '<span class="screen-reader-text">' . esc_html__( 'Photos:', 'stubli' ) . ' </span>' . (int) count( $ids ) . '</span>', stubli_allowed_html() );
		} elseif ( $ids && stubli_video_for( $ids[0] ) ) {
			echo wp_kses( '<span class="st-badge">' . stubli_icon( 'play', 14 ) . '<span class="screen-reader-text">' . esc_html__( 'Video', 'stubli' ) . '</span></span>', stubli_allowed_html() );
		}
		if ( $note ) {
			echo '<span class="st-tile-note">' . esc_html( $note ) . '</span>';
		}
		if ( ! empty( $post->stubli_pinned ) ) {
			echo wp_kses( '<span class="st-badge st-badge-pin">' . stubli_icon( 'pin', 14 ) . '<span class="screen-reader-text">' . esc_html__( 'Pinned', 'stubli' ) . '</span></span>', stubli_allowed_html() );
		}
		echo '</span><span class="st-tile-caption"><span class="st-muted">' . esc_html( stubli_short_date( $post ) ) . '</span> · ' . esc_html( stubli_post_label( $post ) ) . '</span>';
		echo '</a></li>';
	}
	echo '</ul>';
}

/**
 * A journal entry filed into a collection, as a tile the same size as the
 * photos around it: its first photo with a page sign, or a paper tile with
 * its title and first lines (DESIGN §11.5).
 *
 * @param WP_Post $post Entry.
 * @param string  $size Image size for photo tiles.
 */
function stubli_entry_tile( $post, $size ) {
	$photo = \Stubli\Journal::tile_photo( $post->ID );
	$title = stubli_entry_title( $post );
	$badge = '<span class="st-badge st-badge-page">' . stubli_icon( 'page', 14 ) . '<span class="screen-reader-text">' . esc_html__( 'Journal entry', 'stubli' ) . '</span></span>';
	echo '<li><a class="st-tile st-tile-entry" href="' . esc_url( get_permalink( $post ) ) . '">';
	if ( $photo ) {
		echo '<span class="st-tile-photo">';
		echo wp_kses( wp_get_attachment_image( $photo, $size, false, array( 'alt' => (string) get_post_meta( $photo, '_wp_attachment_image_alt', true ), 'loading' => 'lazy', 'sizes' => '(min-width: 1280px) 240px, (min-width: 768px) 30vw, 46vw' ) ), stubli_allowed_html() );
	} else {
		echo '<span class="st-tile-photo st-tile-paper">';
		if ( '' !== $title ) {
			echo '<span class="st-paper-h">' . esc_html( $title ) . '</span>';
		}
		echo '<span class="st-paper-b">' . esc_html( \Stubli\Journal::opening( $post, 45 ) ) . '</span>';
	}
	if ( ! empty( $post->stubli_pinned ) ) {
		echo wp_kses( '<span class="st-badge st-badge-pin">' . stubli_icon( 'pin', 14 ) . '<span class="screen-reader-text">' . esc_html__( 'Pinned', 'stubli' ) . '</span></span>', stubli_allowed_html() );
	}
	echo wp_kses( $badge, stubli_allowed_html() );
	echo '</span><span class="st-tile-caption"><span class="st-muted">' . esc_html( stubli_short_date( $post ) ) . '</span> · ' . esc_html( '' !== $title ? $title : __( 'Journal entry', 'stubli' ) ) . '</span>';
	echo '</a></li>';
}

/**
 * Comments on a post or page.
 *
 * @param int $post_id Post ID.
 */
function stubli_comments( $post_id ) {
	$comments = stubli_has_plugin() ? \Stubli\Moderation::for_post( $post_id ) : array();
	?>
	<section class="st-comments" aria-labelledby="st-comments-h">
		<h2 id="st-comments-h"><?php esc_html_e( 'Comments', 'stubli' ); ?></h2>
		<?php if ( ! $comments ) : ?>
			<p class="st-muted"><?php esc_html_e( 'No comments yet.', 'stubli' ); ?></p>
		<?php endif; ?>
		<?php foreach ( $comments as $c ) : ?>
			<div class="st-comment<?php echo $c['parent'] ? ' is-reply' : ''; ?>">
				<img class="st-comment-avatar" src="<?php echo esc_url( stubli_img_src( $c['author']['avatar'] ), array( 'http', 'https', 'data' ) ); ?>" alt="" width="32" height="32" loading="lazy">
				<div>
					<p class="st-comment-meta"><a href="<?php echo esc_url( $c['author']['url'] ); ?>"><strong><?php echo esc_html( $c['author']['name'] ); ?></strong></a> <span class="st-muted"><?php echo esc_html( (string) wp_parse_url( $c['author']['url'], PHP_URL_HOST ) ); ?> · <?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $c['date'] ) ) ); ?></span></p>
					<p class="st-comment-text"><?php echo esc_html( $c['text'] ); ?></p>
				</div>
			</div>
		<?php endforeach; ?>
		<?php if ( stubli_profile()['on_break'] ) : ?>
			<p class="st-break"><?php esc_html_e( 'Comments are paused for now.', 'stubli' ); ?></p>
		<?php elseif ( ! stubli_is_owner() ) : ?>
			<?php echo wp_kses( stubli_pill( stubli_remote_url( 'comment', get_permalink( $post_id ) ), __( 'Comment from your own Stubli', 'stubli' ), 'quiet' ), stubli_allowed_html() ); ?>
		<?php endif; ?>
		<?php if ( stubli_is_owner() && 'post' === get_post_type( $post_id ) ) : ?>
			<?php echo wp_kses( stubli_pill( home_url( '/app/#comments/' . (int) $post_id ), __( 'Add a comment', 'stubli' ), 'quiet' ), stubli_allowed_html() ); ?>
		<?php endif; ?>
		<?php if ( stubli_is_owner() && in_array( get_post_format( $post_id ), array( 'image', 'gallery' ), true ) ) : ?>
			<?php echo wp_kses( stubli_pill( home_url( '/app/#edit/' . (int) $post_id ), __( 'Edit in the app', 'stubli' ), 'quiet' ), stubli_allowed_html() ); ?>
		<?php endif; ?>
	</section>
	<?php
}

/**
 * Footer: © years and name; "Made with stübli" only if the owner turned it on.
 */
function stubli_footer() {
	$now = (int) wp_date( 'Y' );
	if ( 'stubli.app' === (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) {
		// The project site: who made Stubli, and that the code is free to use.
		?>
	<footer class="st-footer st-footer-hub">
		<nav class="st-footer-links" aria-label="<?php esc_attr_e( 'More about Stubli', 'stubli' ); ?>">
			<?php
			$links = array();
			$help  = get_page_by_path( 'help' );
			if ( $help && 'publish' === $help->post_status ) {
				$links[] = '<a href="' . esc_url( get_permalink( $help ) ) . '">' . esc_html__( 'Help', 'stubli' ) . '</a>';
			}
			$how = get_page_by_path( 'how-it-works' );
			if ( $how && 'publish' === $how->post_status ) {
				$links[] = '<a href="' . esc_url( get_permalink( $how ) ) . '">' . esc_html__( 'How it works', 'stubli' ) . '</a>';
			}
			$links[] = '<a href="https://github.com/celestinetan/stubli-plugin">' . esc_html__( 'See the code', 'stubli' ) . '</a>';
			$links[] = '<a href="https://buymeacoffee.com/celestinetan">' . esc_html__( 'Support Stubli', 'stubli' ) . '</a>';
			$links[] = '<a href="' . esc_url( home_url( '/privacy/' ) ) . '">' . esc_html__( 'Privacy', 'stubli' ) . '</a>';
			echo wp_kses( implode( '<span aria-hidden="true">·</span>', $links ), stubli_allowed_html() );
			?>
		</nav>
		<p class="st-footer-copy">&copy; <?php echo (int) $now; ?> Celestine Tan</p>
	</footer>
		<?php
		return;
	}
	// Everyone else's Stubli: their photos and words are theirs.
	$first = get_posts(
		array(
			'numberposts' => 1,
			'orderby'     => 'date',
			'order'       => 'ASC',
			'post_status' => 'publish',
			'fields'      => 'ids',
		)
	);
	$from  = $first ? (int) get_the_date( 'Y', $first[0] ) : $now;
	$years = $from && $from < $now ? $from . '–' . $now : (string) $now;
	?>
	<footer class="st-footer">
		<span>&copy; <?php echo esc_html( $years . ' ' . get_bloginfo( 'name' ) ); ?></span>
		<?php if ( stubli_credit_on() && empty( $GLOBALS['stubli_own_shown'] ) ) : // Once per page; only if the owner said yes in setup or in Settings → Stubli. ?>
			<span aria-hidden="true">·</span>
			<a href="https://stubli.app/"><?php esc_html_e( 'Made with', 'stubli' ); ?> <?php echo wp_kses( stubli_wordmark(), stubli_allowed_html() ); ?></a>
		<?php endif; ?>
	</footer>
	<?php
}

/* ───────────────────────── Views ───────────────────────── */

/**
 * Profile: cards, tabs, the active collection's panel.
 */
function stubli_view_profile() {
	$collections = stubli_collections();
	$active      = 0;
	if ( is_category() ) {
		$active = (int) get_queried_object_id();
	} elseif ( $collections && ! stubli_has_all() ) {
		$active = (int) $collections[0]->term_id;
	}
	$term = $active ? get_term( $active, 'category' ) : null;
	stubli_topbar();
	echo '<main class="st-main" id="main">';
	$moved = (string) get_option( 'stubli_moved_to', '' );
	if ( $moved ) {
		/* translators: %s: new address */
		echo '<p class="st-card-tone st-moved" role="status">' . sprintf( esc_html__( 'This Stubli has moved to %s.', 'stubli' ), '<a href="' . esc_url( $moved ) . '">' . esc_html( untrailingslashit( preg_replace( '#^https?://#', '', $moved ) ) ) . '</a>' ) . '</p>';
	}
	if ( function_exists( 'stubli_hub_welcome' ) && ! is_category() ) {
		stubli_hub_welcome();
	}
	stubli_profile_cards();
	stubli_tabs( $active );
	$first = stubli_has_all() ? 0 === $active : ( $collections && (int) $collections[0]->term_id === $active );
	echo '<section class="st-panel' . ( $first ? ' is-first' : '' ) . '">';
	if ( $term && ! is_wp_error( $term ) && '' !== trim( $term->description ) ) {
		echo '<p class="st-wall-label">' . esc_html( wp_strip_all_tags( $term->description ) ) . '</p>';
	}
	stubli_grid( stubli_photos( $active ) );
	echo '</section>';
	stubli_make_your_own();
	echo '</main>';
}

/**
 * One photo post (or a journal entry on its own).
 */
function stubli_view_single() {
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post ) {
		stubli_view_notfound();
		return;
	}
	if ( has_post_format( 'status', $post ) ) {
		stubli_topbar( home_url( '/journal/' ), __( 'Journal', 'stubli' ) );
		echo '<main class="st-main st-reading" id="main"><article class="st-entry is-full">';
		$title = stubli_entry_title( $post );
		if ( '' !== $title ) {
			echo '<p class="st-entry-date">' . esc_html( get_the_date( 'l, j F Y', $post ) ) . '</p>';
			echo '<h1 class="st-entry-title">' . esc_html( $title ) . '</h1>';
		} else {
			echo '<h1 class="st-entry-date">' . esc_html( get_the_date( 'l, j F Y', $post ) ) . '</h1>';
		}
		echo wp_kses( stubli_entry_meta( $post ), stubli_allowed_html() );
		echo wp_kses( '<div class="st-entry-text">' . stubli_entry_html( $post ) . '</div>', stubli_allowed_html() );
		echo '</article>';
		stubli_comments( $post->ID );
		echo '</main>';
		return;
	}

	$ids  = stubli_photo_ids( $post->ID );
	$coll = stubli_post_collection( $post->ID );
	$note = (string) get_post_meta( $post->ID, '_stubli_content_note', true );
	$name = get_bloginfo( 'name' );
	stubli_topbar( $coll ? get_category_link( $coll ) : home_url( '/' ), $name );
	// A landscape cover gets the full width on bigger screens, with the words underneath.
	$wide = stubli_is_landscape( $ids ? $ids[0] : 0 );
	echo '<main class="st-main st-post" id="main"><article class="st-post-grid' . ( $wide ? ' is-wide' : '' ) . '">';
	echo '<h1 class="screen-reader-text">' . esc_html( stubli_post_label( $post ) ) . '</h1>';

	echo '<div class="st-carousel' . ( $note ? ' has-note' : '' ) . '" data-st-carousel>';
	echo '<div class="st-carousel-track" tabindex="0" aria-label="' . esc_attr__( 'Photos', 'stubli' ) . '">';
	foreach ( $ids as $i => $id ) {
		$img = wp_get_attachment_image( $id, 'stubli-large', false, array( 'loading' => 0 === $i ? 'eager' : 'lazy', 'sizes' => $wide ? '(min-width: 1024px) 980px, 100vw' : '(min-width: 1024px) 600px, 100vw' ) );
		$vid = stubli_video_for( $id );
		if ( $vid ) {
			// Tap to play, with sound (nothing loads until then).
			$alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
			echo wp_kses( '<figure class="st-slide st-slide-video"><button type="button" class="st-play" data-st-video="' . esc_url( wp_get_attachment_url( $vid ) ) . '" data-type="' . esc_attr( get_post_mime_type( $vid ) ) . '" data-label="' . esc_attr( $alt ) . '" aria-label="' . esc_attr( $alt ? sprintf( /* translators: %s: video description */ __( 'Play video: %s', 'stubli' ), $alt ) : __( 'Play video', 'stubli' ) ) . '">' . $img . '<span class="st-play-icon">' . stubli_icon( 'play', 30 ) . '</span></button></figure>', stubli_allowed_html() );
		} else {
			// Tap or click to see it full screen, at full size (stubli.js).
			$alt   = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
			/* translators: %d: photo number */
			$label = sprintf( __( 'See photo %d full screen', 'stubli' ), $i + 1 );
			echo wp_kses( '<figure class="st-slide"><button type="button" class="st-zoom" data-st-zoom="' . esc_url( wp_get_attachment_url( $id ) ) . '" data-alt="' . esc_attr( $alt ) . '" aria-label="' . esc_attr( '' !== $alt ? $alt . ' · ' . $label : $label ) . '">' . $img . '<span class="st-zoom-icon">' . stubli_icon( 'expand', 18 ) . '</span></button></figure>', stubli_allowed_html() );
		}
	}
	echo '</div>';
	if ( count( $ids ) > 1 ) {
		/* translators: 1: current photo, 2: number of photos */
		echo '<span class="st-carousel-count" aria-live="polite">' . esc_html( sprintf( __( '%1$d of %2$d', 'stubli' ), 1, count( $ids ) ) ) . '</span>';
		echo wp_kses( '<div class="st-dots" aria-hidden="true">' . str_repeat( '<span></span>', count( $ids ) ) . '</div>', stubli_allowed_html() );
	}
	if ( $note ) {
		echo wp_kses( '<button type="button" class="st-note-reveal" data-st-reveal>' . stubli_icon( 'eye', 20 ) . '<span><strong>' . esc_html( $note ) . '</strong><span>' . esc_html__( 'Show photo', 'stubli' ) . '</span></span></button>', stubli_allowed_html() );
	}
	echo '</div>';

	echo '<div class="st-post-side">';
	echo '<p class="st-post-meta st-muted">' . esc_html( get_the_date( 'F Y', $post ) );
	$edited = (int) get_post_meta( $post->ID, '_stubli_edited', true );
	if ( $edited ) {
		// The photos changed after posting (added, removed or replaced).
		/* translators: %s: date and time */
		echo ' · <span class="st-post-edited" title="' . esc_attr( sprintf( __( 'Edited %s', 'stubli' ), wp_date( 'j M Y, ' . get_option( 'time_format' ), $edited ) ) ) . '">' . esc_html__( 'Edited', 'stubli' ) . '</span>';
	}
	if ( $coll ) {
		echo ' · <a href="' . esc_url( get_category_link( $coll ) ) . '">' . esc_html( stubli_collection_name( $coll ) ) . '</a>';
	}
	echo '</p>';
	echo '<div class="st-caption">' . wp_kses_post( wpautop( $post->post_content ) ) . '</div>';
	stubli_comments( $post->ID );

	$hand = $coll ? stubli_hand_ids( (int) $coll->term_id ) : null;
	if ( null !== $hand ) {
		// In a collection arranged by hand: the ones before and after it in that order.
		$at   = array_search( (int) $post->ID, $hand, true );
		$prev = false !== $at && $at > 0 ? get_post( $hand[ $at - 1 ] ) : null;
		$next = false !== $at && isset( $hand[ $at + 1 ] ) ? get_post( $hand[ $at + 1 ] ) : null;
	} else {
		// Newest first, like the grid: Previous is the newer one, Next the older one.
		$prev = $coll ? get_adjacent_post( true, '', false, 'category' ) : get_adjacent_post( false, '', false );
		$next = $coll ? get_adjacent_post( true, '', true, 'category' ) : get_adjacent_post( false, '', true );
	}
	$card = static function ( $p, $is_next ) use ( $coll ) {
		if ( ! $p || has_post_format( 'status', $p ) ) {
			return '';
		}
		$ids = stubli_photo_ids( $p->ID );
		if ( $coll ) {
			/* translators: %s: collection */
			$label = sprintf( $is_next ? __( 'Next in %s', 'stubli' ) : __( 'Previous in %s', 'stubli' ), stubli_collection_name( $coll ) );
		} else {
			$label = $is_next ? __( 'Next', 'stubli' ) : __( 'Previous', 'stubli' );
		}
		return '<a class="st-card-tone st-next' . ( $is_next ? '' : ' is-prev' ) . '" href="' . esc_url( get_permalink( $p ) ) . '" rel="' . ( $is_next ? 'next' : 'prev' ) . '">'
			. ( $is_next ? '' : stubli_icon( 'back', 20 ) )
			. ( $ids ? wp_get_attachment_image( $ids[0], 'thumbnail', false, array( 'alt' => '' ) ) : '' )
			. '<span><span class="st-muted">' . esc_html( $label ) . '</span><span>' . esc_html( stubli_post_label( $p ) ) . '</span></span>'
			. ( $is_next ? stubli_icon( 'chev', 20 ) : '' ) . '</a>';
	};
	$cards = $card( $prev, false ) . $card( $next, true );
	if ( '' !== $cards ) {
		echo wp_kses( '<nav class="st-adjacent" aria-label="' . esc_attr__( 'More posts', 'stubli' ) . '">' . $cards . '</nav>', stubli_allowed_html() );
	}
	echo '</div></article></main>';
}

/**
 * Whether a photo is landscape (clearly wider than tall, like 3:2).
 *
 * @param int $id Attachment ID.
 * @return bool
 */
function stubli_is_landscape( $id ) {
	$meta = $id ? wp_get_attachment_metadata( $id ) : array();
	return ! empty( $meta['width'] ) && ! empty( $meta['height'] ) && $meta['width'] / $meta['height'] > 1.2;
}

/**
 * Under an entry's date: when it was last edited, and for the owner an Edit
 * link into the app.
 *
 * @param WP_Post $post Entry.
 * @return string
 */
function stubli_entry_meta( $post ) {
	$edited = (int) get_post_meta( $post->ID, '_stubli_edited', true );
	$out    = '';
	if ( $edited ) {
		/* translators: %s: date and time */
		$out .= '<span class="st-entry-edited">' . esc_html( sprintf( __( 'Edited %s', 'stubli' ), wp_date( 'j M Y, ' . get_option( 'time_format' ), $edited ) ) ) . '</span>';
	}
	if ( stubli_is_owner() ) {
		$out .= '<a class="st-entry-edit" href="' . esc_url( home_url( '/app/#journal/' . $post->ID ) ) . '">' . stubli_icon( 'pen', 14 ) . esc_html__( 'Edit', 'stubli' ) . '</a>';
	}
	return '' !== $out ? '<p class="st-entry-meta">' . $out . '</p>' : '';
}

/**
 * A journal entry's HTML, with video links turned into click-to-play
 * (nothing loads from YouTube or Vimeo until pressed).
 *
 * @param WP_Post $post Entry.
 * @return string
 */
function stubli_entry_html( $post ) {
	$html = wpautop( $post->post_content );
	$html = preg_replace_callback(
		'#<a [^>]*href="(https?://(?:www\.)?(?:youtube\.com/watch\?v=|youtu\.be/|vimeo\.com/)([A-Za-z0-9_-]+)[^"]*)"[^>]*>[^<]*</a>#i',
		static function ( $m ) {
			$is_vimeo = false !== stripos( $m[1], 'vimeo.com' );
			$src      = $is_vimeo ? 'https://player.vimeo.com/video/' . rawurlencode( $m[2] ) . '?dnt=1&autoplay=1' : 'https://www.youtube-nocookie.com/embed/' . rawurlencode( $m[2] ) . '?autoplay=1';
			$from     = $is_vimeo ? 'Vimeo' : 'YouTube';
			return '<span class="st-video" data-st-video="' . esc_url( $src ) . '"><button type="button" class="st-video-play" aria-label="' . esc_attr__( 'Play video', 'stubli' ) . '">' . stubli_icon( 'play', 22 ) . '</button></span><span class="st-video-note">' . esc_html( sprintf( /* translators: %s: YouTube or Vimeo */ __( 'Video from %s · loads only when you press play', 'stubli' ), $from ) ) . '</span>';
		},
		$html
	);
	// Screen readers hear which checklist items are ticked.
	$html = preg_replace( '#<li data-checked="true">#', '<li data-checked="true"><span class="screen-reader-text">' . esc_html__( 'Done:', 'stubli' ) . ' </span>', $html );
	return wp_kses_post( $html ) === $html ? $html : stubli_kses_entry( $html );
}

/**
 * Allow the click-to-play markup through kses.
 *
 * @param string $html HTML.
 * @return string
 */
function stubli_kses_entry( $html ) {
	$allowed                          = wp_kses_allowed_html( 'post' );
	$allowed['span']['data-st-video'] = true;
	$allowed['button']                = array(
		'type'       => true,
		'class'      => true,
		'aria-label' => true,
	);
	$allowed['svg']                   = array( 'class' => true, 'width' => true, 'height' => true, 'viewbox' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'aria-hidden' => true, 'focusable' => true );
	$allowed['path']                  = array( 'd' => true, 'fill' => true );
	return wp_kses( $html, $allowed );
}

/**
 * Journal tab.
 */
function stubli_view_journal() {
	stubli_topbar();
	echo '<main class="st-main" id="main">';
	stubli_profile_cards();
	stubli_tabs( 'journal' );
	echo '<section class="st-panel st-journal">';
	if ( 'all' === get_query_var( 'stubli_journal' ) ) {
		stubli_journal_contents();
		echo '</section></main>';
		return;
	}
	$entries = new WP_Query(
		array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 10,
			'paged'          => max( 1, (int) get_query_var( 'paged' ) ),
			'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => 'post_format',
					'field'    => 'slug',
					'terms'    => array( 'post-format-status' ),
				),
			),
		)
	);
	if ( ! $entries->have_posts() ) {
		echo wp_kses( stubli_empty( 'journal' ), stubli_allowed_html() );
	} else {
		// A quiet way to every entry, at the top (and again at the bottom when there are more entries). No count, like everywhere in Stubli.
		echo '<p class="st-journal-nav"><a href="' . esc_url( home_url( '/journal/all/' ) ) . '">' . esc_html__( 'All entries', 'stubli' ) . '</a></p>';
	}
	foreach ( $entries->posts as $entry ) {
		$long  = mb_strlen( wp_strip_all_tags( $entry->post_content ) ) > 600;
		$title = stubli_entry_title( $entry );
		echo '<article class="st-entry' . ( $long ? ' is-long' : '' ) . '">';
		$when = '<time datetime="' . esc_attr( get_post_time( 'c', true, $entry ) ) . '">' . esc_html( get_the_date( 'l, j F', $entry ) ) . '</time>';
		if ( '' !== $title ) {
			echo wp_kses( '<p class="st-entry-date">' . $when . '</p>', stubli_allowed_html() );
			echo '<h2 class="st-entry-title"><a href="' . esc_url( get_permalink( $entry ) ) . '">' . esc_html( $title ) . '</a></h2>';
		} else {
			echo wp_kses( '<h2 class="st-entry-date">' . $when . '</h2>', stubli_allowed_html() );
		}
		echo wp_kses( stubli_entry_meta( $entry ), stubli_allowed_html() );
		echo wp_kses( '<div class="st-entry-text">' . stubli_entry_html( $entry ) . '</div>', stubli_allowed_html() );
		if ( $long ) {
			echo '<a class="st-read-more" href="' . esc_url( get_permalink( $entry ) ) . '">' . esc_html__( 'Read more', 'stubli' ) . '</a>';
		}
		echo '</article>';
	}
	if ( $entries->have_posts() ) {
		$page  = max( 1, (int) get_query_var( 'paged' ) );
		$links = array();
		if ( $page < (int) $entries->max_num_pages ) {
			$links[] = '<a href="' . esc_url( home_url( '/journal/page/' . ( $page + 1 ) . '/' ) ) . '">' . esc_html__( 'More entries', 'stubli' ) . '</a>';
		}
		if ( $page > 1 ) {
			$links[] = '<a href="' . esc_url( 2 === $page ? home_url( '/journal/' ) : home_url( '/journal/page/' . ( $page - 1 ) . '/' ) ) . '">' . esc_html__( 'Newer entries', 'stubli' ) . '</a>';
		}
		// With more than one page, "All entries" sits again beside More/Newer entries; a short journal shows it once, at the top.
		if ( $links ) {
			$links[] = '<a href="' . esc_url( home_url( '/journal/all/' ) ) . '">' . esc_html__( 'All entries', 'stubli' ) . '</a>';
			echo wp_kses( '<p class="st-more st-journal-more">' . implode( '<span aria-hidden="true">·</span>', $links ) . '</p>', stubli_allowed_html() );
		}
	}
	echo '</section></main>';
}

/**
 * The title the owner gave a journal entry, or '' when it has none.
 *
 * @param WP_Post $post Entry.
 * @return string
 */
function stubli_entry_title( $post ) {
	return (string) get_post_meta( $post->ID, '_stubli_title', true );
}

/**
 * "All entries": every public journal entry, grouped by month, newest
 * first. One line each: the day and the title, or the first few words.
 */
function stubli_journal_contents() {
	echo '<div class="st-contents">';
	echo wp_kses( '<p class="st-journal-nav"><a href="' . esc_url( home_url( '/journal/' ) ) . '">' . stubli_icon( 'back', 16 ) . esc_html__( 'Journal', 'stubli' ) . '</a></p>', stubli_allowed_html() );
	echo '<h2 class="st-contents-h">' . esc_html__( 'All entries', 'stubli' ) . '</h2>';
	$items = stubli_has_plugin() ? \Stubli\Journal::contents( false ) : array();
	if ( ! $items ) {
		echo wp_kses( stubli_empty( 'journal' ), stubli_allowed_html() );
		echo '</div>';
		return;
	}
	$month = '';
	foreach ( $items as $it ) {
		$m = wp_date( 'F Y', $it['time'] );
		if ( $m !== $month ) {
			echo ( '' !== $month ? '</ul></section>' : '' ) . '<section class="st-contents-month"><h3>' . esc_html( $m ) . '</h3><ul role="list">';
			$month = $m;
		}
		echo '<li><a href="' . esc_url( $it['url'] ) . '"><time datetime="' . esc_attr( gmdate( 'c', $it['time'] ) ) . '">' . esc_html( wp_date( 'D j', $it['time'] ) ) . '</time><span' . ( '' === $it['title'] ? ' class="is-words"' : '' ) . '>' . esc_html( $it['label'] ) . '</span></a></li>';
	}
	echo '</ul></section></div>';
}

/**
 * Guest book tab.
 */
function stubli_view_guestbook() {
	$page  = get_queried_object();
	$owner = stubli_is_owner();
	stubli_topbar();
	echo '<main class="st-main" id="main">';
	stubli_profile_cards();
	stubli_tabs( 'guest' );
	$entries = stubli_has_plugin() ? \Stubli\Guestbook::entries() : array();
	$count   = count( $entries );
	echo '<section class="st-panel st-gb">';
	// Heading, how many have signed, and the way to sign.
	echo '<div class="st-gb-head"><div><h2 class="st-gb-title">' . esc_html__( 'Guest book', 'stubli' ) . '</h2>';
	if ( $count ) {
		/* translators: %s: number of entries */
		echo '<p class="st-muted st-gb-count">' . esc_html( sprintf( _n( '%s signature', '%s signatures', $count, 'stubli' ), number_format_i18n( $count ) ) ) . '</p>';
	}
	echo '</div>';
	if ( stubli_profile()['on_break'] ) {
		echo '<p class="st-break">' . esc_html__( 'The guest book is paused for now.', 'stubli' ) . '</p>';
	} elseif ( ! $owner && $page instanceof WP_Post ) {
		echo wp_kses( stubli_pill( stubli_remote_url( 'sign', get_permalink( $page ) ), __( 'Sign the guest book', 'stubli' ) ), stubli_allowed_html() );
	}
	echo '</div>';
	if ( $page instanceof WP_Post && '' !== trim( $page->post_content ) ) {
		echo '<p class="st-wall-label st-gb-intro">' . esc_html( trim( html_entity_decode( wp_strip_all_tags( $page->post_content ), ENT_QUOTES ) ) ) . '</p>';
	}
	if ( ! $entries ) {
		echo wp_kses( '<div class="st-gb-empty">' . stubli_icon( 'pen', 22 ) . '<p><strong>' . esc_html__( 'No signatures yet', 'stubli' ) . '</strong><br>' . esc_html( $owner ? __( 'When friends sign from their own Stubli, their words appear here.', 'stubli' ) : __( 'Be the first to say hello.', 'stubli' ) ) . '</p></div>', stubli_allowed_html() );
	}
	echo '<div class="st-gb-list"' . ( $owner ? ' data-st-gb data-nonce="' . esc_attr( wp_create_nonce( 'wp_rest' ) ) . '" data-api="' . esc_url( rest_url( 'og/v1/guestbook/' ) ) . '"' : '' ) . '>';
	foreach ( $entries as $e ) {
		$host = (string) wp_parse_url( $e['author']['url'], PHP_URL_HOST );
		echo '<article class="st-gb-card' . ( $e['pinned'] ? ' is-pinned' : '' ) . '">';
		if ( $e['pinned'] ) {
			echo wp_kses( '<span class="st-gb-pin">' . stubli_icon( 'pin', 13 ) . esc_html__( 'Pinned', 'stubli' ) . '</span>', stubli_allowed_html() );
		}
		echo '<p class="st-gb-text">' . esc_html( $e['text'] ) . '</p>';
		echo '<footer class="st-gb-sig"><img src="' . esc_url( stubli_img_src( $e['author']['avatar'] ), array( 'http', 'https', 'data' ) ) . '" alt="" width="28" height="28" loading="lazy">';
		echo '<span><a href="' . esc_url( $e['author']['url'] ) . '">' . esc_html( $e['author']['name'] ) . '</a><span class="st-muted">' . esc_html( $host ) . ' · <time datetime="' . esc_attr( $e['date'] ) . '">' . esc_html( wp_date( 'j M Y', strtotime( $e['date'] ) ) ) . '</time></span></span>';
		if ( $owner ) {
			/* translators: %s: name */
			echo wp_kses( '<button type="button" class="st-gb-pinbtn" data-st-gb-pin="' . (int) $e['id'] . '" data-pinned="' . ( $e['pinned'] ? '1' : '0' ) . '" aria-label="' . esc_attr( sprintf( $e['pinned'] ? __( 'Unpin the entry from %s', 'stubli' ) : __( 'Pin the entry from %s to the top', 'stubli' ), $e['author']['name'] ) ) . '">' . stubli_icon( 'pin', 15 ) . '<span>' . esc_html( $e['pinned'] ? __( 'Unpin', 'stubli' ) : __( 'Pin', 'stubli' ) ) . '</span></button>', stubli_allowed_html() );
		}
		echo '</footer></article>';
	}
	echo '</div></section></main>';
}

/**
 * Favourites tab (once Links): one tile per group, favourites without a
 * group first, then the sites I follow. All on one page (29-30 Oct).
 */
function stubli_view_links() {
	stubli_topbar();
	echo '<main class="st-main" id="main">';
	stubli_profile_cards();
	stubli_tabs( 'links' );
	echo '<section class="st-panel st-links is-last">';
	echo '<div class="st-gb-head"><div><h2 class="st-gb-title">' . esc_html__( 'Favourites', 'stubli' ) . '</h2></div></div>';
	// One tile per group, side by side on bigger screens (Celestine, 30 Oct); favourites without a group come first, in a tile with no heading.
	$secs = stubli_favourite_sections();
	if ( $secs ) {
		echo '<div class="st-fav-tiles">';
	}
	foreach ( $secs as $sec ) {
		echo '' !== $sec['group'] ? '<section class="st-fav-tile" aria-label="' . esc_attr( $sec['group'] ) . '"><h3 class="st-links-h">' . esc_html( $sec['group'] ) . '</h3>' : '<section class="st-fav-tile is-loose" aria-label="' . esc_attr__( 'Favourites', 'stubli' ) . '">';
		echo '<div class="st-link-list">';
		foreach ( $sec['items'] as $l ) {
			$sub  = '' !== $l['note'] ? $l['note'] : ( '' !== $l['url'] ? preg_replace( '#^https?://(www\.)?#', '', untrailingslashit( $l['url'] ) ) : '' );
			$body = '<span><strong>' . esc_html( $l['label'] ) . '</strong>' . ( '' !== $sub ? '<span class="st-muted">' . esc_html( $sub ) . '</span>' : '' ) . '</span>';
			if ( '' !== $l['url'] ) {
				$label = $l['map'] ? sprintf( /* translators: %s: name of a favourite place */ __( '%s, on a map', 'stubli' ), $l['label'] ) : '';
				echo wp_kses( '<a class="st-link-row" href="' . esc_url( $l['url'] ) . '" rel="me noopener"' . ( $label ? ' aria-label="' . esc_attr( $label . ( '' !== $l['note'] ? '. ' . $l['note'] : '' ) ) . '"' : '' ) . '>' . $body . stubli_icon( $l['map'] ? 'place' : 'chev', 18 ) . '</a>', stubli_allowed_html() );
			} else {
				echo wp_kses( '<div class="st-link-row is-plain">' . $body . '</div>', stubli_allowed_html() );
			}
		}
		echo '</div></section>';
	}
	if ( $secs ) {
		echo '</div>';
	}
	$sites = stubli_has_plugin() ? \Stubli\Follows::public_list() : array();
	echo '<h3 class="st-links-h">' . esc_html__( 'Sites I follow', 'stubli' ) . ' <span class="st-muted st-normal">' . esc_html__( '· people I like to visit', 'stubli' ) . '</span></h3>';
	echo '<div class="st-link-list">';
	if ( ! $sites ) {
		echo '<p class="st-empty">' . esc_html__( 'Not following anyone yet.', 'stubli' ) . '</p>';
	}
	foreach ( $sites as $s ) {
		echo '<a class="st-site-row" href="' . esc_url( $s['url'] ) . '">';
		echo '<img src="' . esc_url( stubli_img_src( $s['avatar'] ), array( 'http', 'https', 'data' ) ) . '" alt="" width="40" height="40" loading="lazy">';
		echo '<span><span><strong>' . esc_html( $s['name'] ) . '</strong> <span class="st-muted">' . esc_html( (string) wp_parse_url( $s['url'], PHP_URL_HOST ) ) . '</span></span>';
		if ( '' !== $s['note'] ) {
			echo '<span>' . esc_html( $s['note'] ) . '</span>';
		}
		echo '</span></a>';
	}
	echo '</div></section></main>';
}

/**
 * "From your own Stubli": ask for the visitor's address, then send them to
 * their own site to follow, comment or sign.
 */
function stubli_view_remote() {
	$do     = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : 'comment'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$target = isset( $_GET['url'] ) ? esc_url_raw( rawurldecode( wp_unslash( $_GET['url'] ) ) ) : home_url( '/' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- decoded, then esc_url_raw().
	if ( wp_parse_url( $target, PHP_URL_HOST ) !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
		$target = home_url( '/' );
	}
	$name   = get_bloginfo( 'name' );
	$titles = array(
		/* translators: %s: name */
		'follow'  => sprintf( __( 'Follow %s from your own Stubli', 'stubli' ), $name ),
		'comment' => __( 'Comment from your own Stubli', 'stubli' ),
		/* translators: %s: name */
		'sign'    => sprintf( __( 'Sign %s\'s guest book', 'stubli' ), $name ),
		/* translators: %s: name */
		'note'    => sprintf( __( 'Reply to %s', 'stubli' ), $name ),
	);
	$do = isset( $titles[ $do ] ) ? $do : 'comment';
	if ( 'note' === $do ) {
		stubli_view_note( $name );
		return;
	}
	stubli_topbar( $target, $name );
	?>
	<main class="st-main st-narrow" id="main">
		<h1 class="st-h1"><?php echo esc_html( $titles[ $do ] ); ?></h1>
		<p class="st-lead">
			<?php
			if ( 'follow' === $do ) {
				esc_html_e( 'Following happens on your own site. Enter your address and we\'ll take you there to confirm.', 'stubli' );
			} else {
				/* translators: %s: name */
				printf( esc_html__( 'You write it on your own site, and it shows up here too. If %1$s follows you, it appears right away; otherwise it waits for %1$s\'s OK.', 'stubli' ), esc_html( $name ) );
			}
			?>
		</p>
		<form class="st-remote" data-st-remote data-do="<?php echo esc_attr( $do ); ?>" data-target="<?php echo esc_url( $target ); ?>">
			<label for="st-addr"><?php esc_html_e( 'Your Stubli address', 'stubli' ); ?></label>
			<input id="st-addr" name="addr" type="url" inputmode="url" autocomplete="url" placeholder="yourname.com" required>
			<span class="st-muted st-small"><?php esc_html_e( 'This device will remember it for next time.', 'stubli' ); ?></span>
			<p class="st-error" role="alert" hidden></p>
			<button type="submit" class="st-button"><?php esc_html_e( 'Continue', 'stubli' ); ?></button>
		</form>
		<section class="st-card-tone st-no-stubli">
			<h2 class="st-h3"><?php esc_html_e( 'No Stubli yet?', 'stubli' ); ?></h2>
			<p>
				<?php
				if ( 'follow' === $do ) {
					/* translators: %s: name */
					printf( esc_html__( 'To follow %s, you need a Stubli of your own: your own little website for photos, a journal and the people you like. Completely free, you just pay for web hosting.', 'stubli' ), esc_html( $name ) );
				} else {
					esc_html_e( 'You need a Stubli of your own for this: your own little website for photos, a journal and the people you like. Completely free, you just pay for web hosting.', 'stubli' );
				}
				?>
			</p>
			<a class="st-button" href="https://stubli.app/welcome/?from=<?php echo esc_attr( $do ); ?>"><?php esc_html_e( 'Make your Stubli', 'stubli' ); ?></a>
		</section>
	</main>
	<?php
}

/**
 * Reply to a prompt card: from your own Stubli, or as a guest with a note
 * only the owner sees (design Q48).
 *
 * @param string $name Owner's name.
 */
function stubli_view_note( $name ) {
	$i      = isset( $_GET['p'] ) ? (int) $_GET['p'] : -1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$p      = stubli_profile();
	$card   = ( $i >= 0 && isset( $p['prompts'][ $i ] ) ) ? $p['prompts'][ $i ] : null;
	$first  = stubli_first_name( $name );
	$paused = ! empty( $p['on_break'] );
	stubli_topbar( home_url( '/' ), $name );
	?>
	<main class="st-main st-narrow" id="main">
		<h1 class="st-h1"><?php /* translators: %s: name */ printf( esc_html__( 'Reply to %s', 'stubli' ), esc_html( $first ) ); ?></h1>
		<?php if ( $card ) : ?>
			<div class="st-card st-prompt st-note-quote"><p class="st-prompt-q"><?php echo esc_html( $card['q'] ); ?></p><p class="st-prompt-a"><?php echo esc_html( $card['a'] ); ?></p></div>
		<?php endif; ?>
		<?php if ( $paused ) : ?>
			<p class="st-break"><?php /* translators: %s: name */ printf( esc_html__( '%s is taking a break, so notes are paused for now.', 'stubli' ), esc_html( $first ) ); ?></p>
		<?php else : ?>
		<div class="st-note-tabs" role="tablist" aria-label="<?php esc_attr_e( 'How to reply', 'stubli' ); ?>" data-st-note-tabs>
			<button type="button" role="tab" id="st-tab-guest" aria-controls="st-pane-guest" aria-selected="true"><?php esc_html_e( 'Leave a note', 'stubli' ); ?></button>
			<button type="button" role="tab" id="st-tab-own" aria-controls="st-pane-own" aria-selected="false"><?php esc_html_e( 'I have a Stubli', 'stubli' ); ?></button>
		</div>
		<section id="st-pane-guest" role="tabpanel" aria-labelledby="st-tab-guest">
			<form class="st-note-form" data-st-note data-url="<?php echo esc_url( rest_url( 'stubli/v1/notes/guest' ) ); ?>" data-prompt="<?php echo (int) $i; ?>" novalidate>
				<label for="st-note-text"><?php esc_html_e( 'Your note', 'stubli' ); ?></label>
				<textarea id="st-note-text" name="text" rows="4" maxlength="1000" required></textarea>
				<label for="st-note-name"><?php esc_html_e( 'Your name', 'stubli' ); ?></label>
				<input id="st-note-name" name="name" type="text" maxlength="60" autocomplete="name" required>
				<label for="st-note-contact"><?php /* translators: %s: first name */ printf( esc_html__( 'How %s can reach you', 'stubli' ), esc_html( $first ) ); ?></label>
				<input id="st-note-contact" name="contact" type="text" maxlength="120" autocomplete="email" placeholder="<?php esc_attr_e( 'Email, phone or Instagram name', 'stubli' ); ?>" required>
				<div class="st-trap" aria-hidden="true"><label for="st-note-website">Website</label><input id="st-note-website" name="website" type="text" tabindex="-1" autocomplete="off"></div>
				<p class="st-muted st-small"><?php /* translators: %s: first name */ printf( esc_html__( 'Only %s sees this note and your contact details. Nothing appears on this page, and it\'s deleted after 90 days.', 'stubli' ), esc_html( $first ) ); ?></p>
				<p class="st-error" role="alert" hidden></p>
				<button type="submit" class="st-button"><?php esc_html_e( 'Send note', 'stubli' ); ?></button>
			</form>
			<div class="st-card-tone st-note-done" data-st-note-done hidden tabindex="-1">
				<p><strong><?php esc_html_e( 'Sent. Thank you!', 'stubli' ); ?></strong></p>
				<p class="st-muted"><?php /* translators: %s: first name */ printf( esc_html__( '%s will see it soon and can write back to you directly.', 'stubli' ), esc_html( $first ) ); ?></p>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php /* translators: %s: first name */ printf( esc_html__( 'Back to %s\'s page', 'stubli' ), esc_html( $first ) ); ?></a>
				<p class="st-note-own st-muted st-small"><?php esc_html_e( 'Want a page like this of your own?', 'stubli' ); ?> <a href="https://stubli.app/welcome/?from=note"><?php esc_html_e( 'Make your Stubli', 'stubli' ); ?></a></p>
			</div>
		</section>
		<section id="st-pane-own" role="tabpanel" aria-labelledby="st-tab-own" hidden>
			<p><?php /* translators: %s: first name */ printf( esc_html__( 'Write it in your own Stubli app. %s gets it as a private note: straight away if they follow you, otherwise after their OK.', 'stubli' ), esc_html( $first ) ); ?></p>
			<form class="st-remote" data-st-remote data-do="note" data-target="<?php echo esc_url( home_url( '/' ) ); ?>" data-p="<?php echo (int) $i; ?>">
				<label for="st-addr"><?php esc_html_e( 'Your Stubli address', 'stubli' ); ?></label>
				<input id="st-addr" name="addr" type="url" inputmode="url" autocomplete="url" placeholder="yourname.com" required>
				<span class="st-muted st-small"><?php esc_html_e( 'This device will remember it for next time.', 'stubli' ); ?></span>
				<p class="st-error" role="alert" hidden></p>
				<button type="submit" class="st-button"><?php esc_html_e( 'Continue in my app', 'stubli' ); ?></button>
			</form>
		</section>
		<?php endif; ?>
	</main>
	<?php
}

/**
 * An invite from the owner: the friend confirms on their own Stubli and
 * both sites follow each other.
 */
function stubli_view_invite() {
	$token = isset( $_GET['t'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', sanitize_text_field( wp_unslash( $_GET['t'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$state = stubli_has_plugin() && class_exists( '\Stubli\Invites' ) ? \Stubli\Invites::check( $token ) : 'unknown';
	$p     = stubli_profile();
	$name  = $p['name'];
	stubli_topbar( home_url( '/' ), $name );
	?>
	<main class="st-main st-narrow" id="main">
		<?php if ( 'ok' === $state ) : ?>
			<div class="st-invite-head">
				<?php if ( ! empty( $p['avatar'] ) ) : ?>
					<img class="st-avatar" src="<?php echo esc_url( stubli_img_src( $p['avatar'] ), array( 'http', 'https', 'data' ) ); ?>" alt="" width="56" height="56">
				<?php endif; ?>
				<h1 class="st-h1"><?php /* translators: %s: name */ printf( esc_html__( '%s invited you to Stubli', 'stubli' ), esc_html( $name ) ); ?></h1>
			</div>
			<p class="st-lead">
				<?php /* translators: %s: name */ printf( esc_html__( 'Stubli is your own little website for photos, a journal and the people you like. Once you\'re set up, you and %s follow each other automatically.', 'stubli' ), esc_html( $name ) ); ?>
			</p>
			<h2 class="st-h3"><?php esc_html_e( 'I already have a Stubli', 'stubli' ); ?></h2>
			<form class="st-remote" data-st-remote data-do="accept" data-target="<?php echo esc_url( home_url( '/' ) ); ?>" data-invite="<?php echo esc_attr( $token ); ?>">
				<label for="st-addr"><?php esc_html_e( 'Your Stubli address', 'stubli' ); ?></label>
				<input id="st-addr" name="addr" type="url" inputmode="url" autocomplete="url" placeholder="yourname.com" required>
				<span class="st-muted st-small"><?php esc_html_e( 'You\'ll confirm on your own site. This device will remember the address.', 'stubli' ); ?></span>
				<p class="st-error" role="alert" hidden></p>
				<button type="submit" class="st-button"><?php esc_html_e( 'Continue', 'stubli' ); ?></button>
			</form>
			<section class="st-card-tone st-no-stubli">
				<h2 class="st-h3"><?php esc_html_e( 'Not yet?', 'stubli' ); ?></h2>
				<p>
					<?php
					/* translators: %s: date */
					printf( esc_html__( 'Setting one up takes about 15 minutes, one small step at a time. We\'ll keep this invite for you, and at the end you and %1$s follow each other. It works until %2$s.', 'stubli' ), esc_html( $name ), esc_html( wp_date( 'j F', \Stubli\Invites::expires( $token ) ) ) );
					?>
				</p>
				<?php
				$start = add_query_arg(
					array(
						'invite' => rawurlencode( add_query_arg( 't', $token, home_url( '/invite/' ) ) ),
						'from'   => rawurlencode( $name ),
					),
					'https://stubli.app/get-started/'
				);
				echo wp_kses( stubli_pill( $start, __( 'Make my Stubli', 'stubli' ) ), stubli_allowed_html() );
				?>
			</section>
		<?php else : ?>
			<section class="st-card-tone st-notfound">
				<?php echo wp_kses( stubli_app_icon( 44 ), stubli_allowed_html() ); ?>
				<h1 class="st-h2">
					<?php
					if ( 'used' === $state ) {
						esc_html_e( 'This invite has already been used', 'stubli' );
					} elseif ( 'expired' === $state ) {
						esc_html_e( 'This invite has expired', 'stubli' );
					} else {
						esc_html_e( 'This invite link doesn\'t work', 'stubli' );
					}
					?>
				</h1>
				<p><?php /* translators: %s: name */ printf( esc_html__( 'Invites work once, for 30 days. Ask %s for a new link.', 'stubli' ), esc_html( $name ) ); ?></p>
				<?php echo wp_kses( stubli_pill( home_url( '/' ), sprintf( /* translators: %s: name */ __( 'Go to %s\'s page', 'stubli' ), $name ), 'quiet' ), stubli_allowed_html() ); ?>
			</section>
		<?php endif; ?>
	</main>
	<?php
}

/**
 * A WordPress page's own content, printed by WordPress's the_content().
 *
 * @param WP_Post $page The page being viewed.
 */
function stubli_the_content( $page ) {
	if ( (int) get_the_ID() !== (int) $page->ID ) {
		// Not the main page of this request: escape it like any post content.
		echo wp_kses_post( apply_filters( 'the_content', $page->post_content ) ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WordPress's own filter.
		return;
	}
	setup_postdata( $page );
	the_content();
}

/**
 * Ordinary pages (the project site's About, Get started, …).
 */
function stubli_view_page() {
	$page = get_queried_object();
	stubli_topbar();
	// stubli.app's elevator pitch: a wide, designed page whose words stay editable as ordinary blocks.
	$wide = array( 'welcome' => 'st-pitch', 'pitch' => 'st-pitch', 'how-it-works' => 'st-pitch st-guide' );
	if ( $page instanceof WP_Post && isset( $wide[ $page->post_name ] ) && class_exists( '\\Stubli\\Feedback' ) && \Stubli\Feedback::is_hub() ) {
		echo '<main class="st-main ' . esc_attr( $wide[ $page->post_name ] ) . '" id="main">';
		stubli_the_content( $page );
		echo '</main>';
		return;
	}
	if ( $page instanceof WP_Post && function_exists( 'stubli_help_view' ) && stubli_help_view( $page ) ) {
		return;
	}
	echo '<main class="st-main st-narrow st-prose" id="main">';
	if ( $page instanceof WP_Post ) {
		echo '<h1 class="st-h1">' . esc_html( get_the_title( $page ) ) . '</h1>';
		// stubli.app's About page is one long page: what, how, join, support, questions.
		if ( 'about' === $page->post_name && function_exists( 'stubli_story_on' ) && stubli_story_on() && class_exists( '\\Stubli\\Feedback' ) && \Stubli\Feedback::is_hub() ) {
			stubli_story( $page );
			echo '</main>';
			return;
		}
		// stubli.app's Get started page is a guided flow: host first, then Stubli.
		if ( 'get-started' === $page->post_name && function_exists( 'stubli_get_started' ) && class_exists( '\\Stubli\\Feedback' ) && \Stubli\Feedback::is_hub() ) {
			stubli_get_started();
			echo '</main>';
			return;
		}
		stubli_the_content( $page );
		if ( 'feedback' === $page->post_name && class_exists( '\\Stubli\\Feedback' ) && \Stubli\Feedback::is_hub() ) {
			stubli_feedback_form();
		}
	}
	echo '</main>';
}

/**
 * The public feedback form (on stubli.app's Send feedback page).
 */
function stubli_feedback_form() {
	$kinds = array(
		'idea'   => array( __( 'An idea', 'stubli' ), __( 'What would make Stubli better?', 'stubli' ), __( 'I wish I could…', 'stubli' ) ),
		'broken' => array( __( 'Something\'s not working', 'stubli' ), __( 'What happened?', 'stubli' ), __( 'I tried to … and then …', 'stubli' ) ),
		'love'   => array( __( 'Kind words', 'stubli' ), __( 'What do you like?', 'stubli' ), __( 'I love that…', 'stubli' ) ),
	);
	?>
	<form class="st-feedback" data-st-feedback data-url="<?php echo esc_url( rest_url( 'stubli/v1/feedback' ) ); ?>" data-version="<?php echo esc_attr( defined( '\\Stubli\\VERSION' ) ? \Stubli\VERSION : '' ); ?>" novalidate>
		<h2 class="st-h3" id="st-fb-kind"><?php esc_html_e( 'What is it about?', 'stubli' ); ?></h2>
		<div class="st-fb-kinds" role="radiogroup" aria-labelledby="st-fb-kind">
			<?php foreach ( $kinds as $key => $k ) : ?>
				<label class="st-fb-kind"><input type="radio" name="kind" value="<?php echo esc_attr( $key ); ?>" data-q="<?php echo esc_attr( $k[1] ); ?>" data-ph="<?php echo esc_attr( $k[2] ); ?>"<?php checked( 'idea', $key ); ?>><span><?php echo esc_html( $k[0] ); ?></span></label>
			<?php endforeach; ?>
		</div>
		<label for="st-fb-text" class="st-fb-label" data-st-q><?php echo esc_html( $kinds['idea'][1] ); ?></label>
		<textarea id="st-fb-text" name="message" rows="6" maxlength="4000" required placeholder="<?php echo esc_attr( $kinds['idea'][2] ); ?>"></textarea>
		<label for="st-fb-reply" class="st-fb-label"><?php esc_html_e( 'Your email or Stubli address', 'stubli' ); ?> <span class="st-muted"><?php esc_html_e( '(optional, so we can reply)', 'stubli' ); ?></span></label>
		<input id="st-fb-reply" name="reply_to" type="text" maxlength="200" autocomplete="email">
		<label for="st-fb-shot" class="st-fb-label"><?php esc_html_e( 'A screenshot', 'stubli' ); ?> <span class="st-muted"><?php esc_html_e( '(optional)', 'stubli' ); ?></span></label>
		<input id="st-fb-shot" name="screenshot" type="file" accept="image/png,image/jpeg,image/webp">
		<div class="st-fb-hp" aria-hidden="true"><label for="st-fb-website">Website</label><input id="st-fb-website" name="website" type="text" tabindex="-1" autocomplete="off"></div>
		<p class="st-muted st-small"><?php esc_html_e( 'We also keep the type of phone or computer you use, to help fix problems. Nothing else.', 'stubli' ); ?></p>
		<p class="st-error" role="alert" hidden></p>
		<button type="submit" class="st-button"><?php esc_html_e( 'Send feedback', 'stubli' ); ?></button>
	</form>
	<div class="st-card-tone st-fb-done" data-st-feedback-done hidden tabindex="-1">
		<h2 class="st-h3"><?php esc_html_e( 'Thank you', 'stubli' ); ?></h2>
		<p><?php esc_html_e( 'Your note is with the Stubli team. If you left an address and asked a question, Celestine will reply.', 'stubli' ); ?></p>
	</div>
	<?php
}

/**
 * Page not found.
 */
function stubli_view_notfound() {
	stubli_topbar();
	?>
	<main class="st-main st-narrow" id="main">
		<section class="st-card-tone st-notfound">
			<?php echo wp_kses( stubli_app_icon( 44, true ), stubli_allowed_html() ); ?>
			<h1 class="st-h2"><?php esc_html_e( 'This page has moved or is gone', 'stubli' ); ?></h1>
			<?php if ( class_exists( '\\Stubli\\Feedback' ) && \Stubli\Feedback::is_hub() ) : ?>
				<p><?php esc_html_e( 'Maybe it was tidied away. These might help:', 'stubli' ); ?></p>
				<div class="st-welcome-actions">
					<?php echo wp_kses( stubli_pill( function_exists( 'stubli_story_url' ) ? stubli_story_url( 'join' ) : home_url( '/get-started/' ), __( 'Make your Stubli', 'stubli' ) ), stubli_allowed_html() ); ?>
					<?php echo wp_kses( stubli_pill( home_url( '/help/' ), __( 'Help', 'stubli' ), 'quiet' ), stubli_allowed_html() ); ?>
				</div>
			<?php else : ?>
				<p><?php /* translators: %s: name */ printf( esc_html__( 'Maybe it was tidied away. %s\'s photos are still here.', 'stubli' ), esc_html( get_bloginfo( 'name' ) ) ); ?></p>
				<?php echo wp_kses( stubli_pill( home_url( '/' ), sprintf( /* translators: %s: name */ __( 'Go to %s\'s page', 'stubli' ), get_bloginfo( 'name' ) ), 'quiet' ), stubli_allowed_html() ); ?>
			<?php endif; ?>
		</section>
	</main>
	<?php
}
