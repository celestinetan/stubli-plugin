<?php
/**
 * The guest book (Q27): a page that receives notes from visitors' own sites.
 *
 * @package Stubli
 */

namespace Stubli;

defined( 'ABSPATH' ) || exit;

/**
 * Visitors sign by writing a reply to the guest book page on their own
 * Stubli; it arrives as a Webmention, like a comment, and follows the same
 * approval rules. The owner can pin entries.
 */
class Guestbook {

	const OPTION    = 'stubli_guestbook_page';
	const GUEST_MAX = 500;

	/**
	 * Register hooks.
	 */
	public static function init() {
		// Nothing to hook yet: the page is created on activation and upgrade.
	}

	/**
	 * Create the guest book page if it doesn't exist.
	 *
	 * @return int Page ID.
	 */
	public static function ensure_page() {
		$id = (int) get_option( self::OPTION, 0 );
		if ( $id && get_post( $id ) ) {
			return $id;
		}
		$existing = get_page_by_path( 'guest-book' );
		if ( $existing ) {
			update_option( self::OPTION, (int) $existing->ID );
			return (int) $existing->ID;
		}
		$id = wp_insert_post(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'post_title'     => __( 'Guest book', 'stubli' ),
				'post_name'      => 'guest-book',
				'post_content'   => '<p>' . esc_html__( 'Thanks for stopping by. Say hello, share a tip, or tell me where you\'re reading from.', 'stubli' ) . '</p>',
				'comment_status' => 'open',
				'ping_status'    => 'open',
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			update_option( self::OPTION, (int) $id );
			return (int) $id;
		}
		return 0;
	}

	/**
	 * @return int
	 */
	public static function page_id() {
		return (int) get_option( self::OPTION, 0 );
	}

	/**
	 * @return string
	 */
	public static function url() {
		$id = self::page_id();
		return $id ? (string) get_permalink( $id ) : '';
	}

	/**
	 * Approved guest book entries, pinned first, then newest.
	 *
	 * @return array[]
	 */
	public static function entries() {
		$id = self::page_id();
		if ( ! $id ) {
			return array();
		}
		$comments = get_comments(
			array(
				'post_id' => $id,
				'status'  => 'approve',
				'orderby' => 'comment_date_gmt',
				'order'   => 'DESC',
			)
		);
		$out = array_map( array( Moderation::class, 'public_comment' ), $comments );
		usort(
			$out,
			static function ( $a, $b ) {
				return (int) $b['pinned'] - (int) $a['pinned'];
			}
		);
		return $out;
	}

	/**
	 * Sign the guest book without a Stubli (0.45.15, Celestine 4 Nov): a name,
	 * a message and, if they like, where they're from. No email, no address,
	 * no links. Every entry waits for the owner's OK. Kept out of spam the way
	 * guest notes are: a trap field, a limit per visitor and per day, and only
	 * a one-way code of the visitor's network address.
	 *
	 * @param array $in name, text, from, website (the trap).
	 * @return array|\WP_Error
	 */
	public static function sign_as_guest( array $in ) {
		if ( '' !== trim( (string) ( $in['website'] ?? '' ) ) ) {
			return array( 'ok' => true );
		}
		$page = self::page_id();
		if ( ! $page || ! get_option( 'stubli_guest_sign', 1 ) ) {
			return new \WP_Error( 'stubli_gb_closed', __( 'This guest book can only be signed from a Stubli.', 'stubli' ), array( 'status' => 403 ) );
		}
		if ( Settings::on_break() ) {
			return new \WP_Error( 'stubli_on_break', __( 'The guest book is paused for now.', 'stubli' ), array( 'status' => 403 ) );
		}
		$name = mb_substr( trim( sanitize_text_field( (string) ( $in['name'] ?? '' ) ) ), 0, 60 );
		$from = mb_substr( trim( sanitize_text_field( (string) ( $in['from'] ?? '' ) ) ), 0, 40 );
		$text = trim( sanitize_textarea_field( (string) ( $in['text'] ?? '' ) ) );
		if ( '' === $text ) {
			return new \WP_Error( 'stubli_gb_text', __( 'Write a few words first.', 'stubli' ), array( 'status' => 400 ) );
		}
		if ( mb_strlen( $text ) > self::GUEST_MAX ) {
			return new \WP_Error( 'stubli_gb_long', __( 'That\'s a little long for a guest book. Trim it to 500 characters and it will fit.', 'stubli' ), array( 'status' => 400 ) );
		}
		if ( '' === $name ) {
			/* translators: %s: the owner's first name */
			return new \WP_Error( 'stubli_gb_name', sprintf( __( 'Add your name, so %s knows who wrote.', 'stubli' ), Notes::owner_first() ), array( 'status' => 400 ) );
		}
		$who = Notes::guest_hash();
		if ( in_array( $who, (array) get_option( Notes::BLOCKED_GUEST, array() ), true ) ) {
			return array( 'ok' => true );
		}
		if ( ! Notes::under_limit( 'gbguest_' . $who, 3, HOUR_IN_SECONDS ) || ! Notes::under_limit( 'gbguests', 30, DAY_IN_SECONDS ) ) {
			return new \WP_Error( 'stubli_gb_limit', __( 'Lots of people have signed recently. Please try again later.', 'stubli' ), array( 'status' => 429 ) );
		}
		$id = wp_insert_comment(
			wp_slash(
				array(
					'comment_post_ID'      => $page,
					'comment_author'       => $name,
					'comment_author_email' => '',
					'comment_author_url'   => '',
					'comment_author_IP'    => '',
					'comment_agent'        => '',
					'comment_content'      => $text,
					'comment_approved'     => 0,
					'comment_type'         => 'comment',
					'comment_meta'         => array(
						'stubli_guest' => $who,
						'stubli_from'  => $from,
					),
				)
			)
		);
		if ( ! $id ) {
			return new \WP_Error( 'stubli_gb_failed', __( 'That didn\'t go through. Try again in a moment.', 'stubli' ), array( 'status' => 500 ) );
		}
		return array( 'ok' => true );
	}

	/**
	 * Pin or unpin an entry.
	 *
	 * @param int  $comment_id Comment ID.
	 * @param bool $pinned     Pin state.
	 * @return bool
	 */
	public static function pin( $comment_id, $pinned ) {
		$comment = get_comment( $comment_id );
		if ( ! $comment || (int) $comment->comment_post_ID !== self::page_id() ) {
			return false;
		}
		if ( $pinned ) {
			update_comment_meta( $comment->comment_ID, 'stubli_pinned', 1 );
		} else {
			delete_comment_meta( $comment->comment_ID, 'stubli_pinned' );
		}
		return true;
	}

	/**
	 * The welcome line at the top of the guest book, as plain text.
	 *
	 * @return string
	 */
	public static function intro() {
		$id = self::page_id();
		return $id ? trim( html_entity_decode( wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) ), ENT_QUOTES ) ) : '';
	}

	/**
	 * Change the welcome line.
	 *
	 * @param string $text Text, up to 300 characters.
	 * @return string|\WP_Error
	 */
	public static function set_intro( $text ) {
		$id = self::page_id();
		if ( ! $id ) {
			return new \WP_Error( 'stubli_no_guestbook', __( 'Your guest book page isn\'t there any more.', 'stubli' ), array( 'status' => 404 ) );
		}
		$text = mb_substr( trim( sanitize_textarea_field( (string) $text ) ), 0, 300 );
		wp_update_post(
			array(
				'ID'           => $id,
				'post_content' => '' === $text ? '' : '<p>' . esc_html( $text ) . '</p>',
			)
		);
		return self::intro();
	}

	/**
	 * Take an entry off the guest book (to the bin, so it can come back).
	 *
	 * @param int  $comment_id Comment ID.
	 * @param bool $restore    Bring it back instead.
	 * @return bool
	 */
	public static function remove( $comment_id, $restore = false ) {
		$comment = get_comment( $comment_id );
		if ( ! $comment || (int) $comment->comment_post_ID !== self::page_id() ) {
			return false;
		}
		return (bool) ( $restore ? wp_untrash_comment( $comment->comment_ID ) : wp_trash_comment( $comment->comment_ID ) );
	}
}
